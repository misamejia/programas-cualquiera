package Conector;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Conexion {
    private PreparedStatement ps;
    private Statement s;
    private static Connection con;
    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String user = "root";
    private static final String paswword = "";
    private static final String url = "jdbc:mysql://localhost/heladeria";

    public Conexion() {
        conectar();
    }

    private void conectar() {
        con = null;
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, user, paswword);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error " + e);
        }

    }

    public boolean validarUsuario(String usuario, String contrasena, String tipoUsuario) {
        String sql = "SELECT * FROM usuarios WHERE nombre_usuario = ? AND contrasena_usuario = ? AND tipo_usuario = ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, contrasena);
            ps.setString(3, tipoUsuario);
        
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al validar el usuario: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
}

    public Connection getConnection() {
        return con;
    }

    public boolean isConnectionOpen() {
        return con != null;
    }
}