/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Contolador;

import static Contolador.ctrlUsuario.id;
import Modelo.PedidoBD;
import Vista.Login;
import Vista.VistaDistrubuidor;
import Vista.VistaPedidosRepartidor;
import Vista.vistaHistorialRepartidor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author WINDOWS 10
 */
public class ControladorDistruibor implements ActionListener, MouseListener {

    private DefaultTableModel tablaPedidos;

    private VistaDistrubuidor vistaMenu;
    private Vista.vistaHistorialRepartidor vistaHistorial;
    private Vista.VistaPedidosRepartidor vistaPedidos;
    private PedidoBD pediosMysql;

    // Instancia privada estática de la clase ControladorDistribuidor
    private static ControladorDistruibor instancia;

    private ControladorDistruibor(VistaDistrubuidor menu) {
        // Crear objetos
        vistaMenu = menu;
        vistaHistorial = new vistaHistorialRepartidor();
        vistaPedidos = new VistaPedidosRepartidor();
        pediosMysql = new PedidoBD();
        tablaPedidos = new DefaultTableModel();
        añadirEscuha();
    }

    public static ControladorDistruibor obtenerInstancia(VistaDistrubuidor menu) {
        if (instancia == null) {
            instancia = new ControladorDistruibor(menu);
        } else {
            instancia.reiniciarEscucha(menu);
        }
        return instancia;
    }

    public void añadirEscuha() {
        //Vista menu
        vistaMenu.getCerrar().addMouseListener(this);
        vistaMenu.getPedidosAsiganados().addMouseListener(this);
        vistaMenu.getHistorial().addMouseListener(this);
        //pedidos
        vistaPedidos.getMenu().addMouseListener(this);
        vistaPedidos.getEnviar().addActionListener(this);
        //Vista historia
        vistaHistorial.getMenu().addMouseListener(this);
        vistaHistorial.getEstado().addActionListener(this);
        pediosMysql.EstadoRepartidor(vistaHistorial.getEstado(), Integer.parseInt(id));
        tituloTablaPedidos();

    }

    public void reiniciarEscucha(VistaDistrubuidor menu) {
        for (MouseListener listener : vistaMenu.getCerrar().getMouseListeners()) {
            vistaMenu.getCerrar().removeMouseListener(listener);
        }
        for (MouseListener listener : vistaMenu.getPedidosAsiganados().getMouseListeners()) {
            vistaMenu.getPedidosAsiganados().removeMouseListener(listener);
        }
        for (MouseListener listener : vistaMenu.getHistorial().getMouseListeners()) {
            vistaMenu.getHistorial().removeMouseListener(listener);
        }
        vistaMenu = menu;
        añadirEscuha();
    }

    //Vista pediso asigandos
    private void actualizarPedidosAsiganos() {
        try {
            vistaPedidos.getActivos().setText("Pedidos Asiganados: " + pediosMysql.ContarPedidosAsiganados(Integer.parseInt(id)));
            vistaPedidos.getArea().setText(pediosMysql.pedidosAceptados(Integer.parseInt(id)));
            vistaPedidos.getCosto().setText("");
            vistaPedidos.getMetodo().setText("");
            pediosMysql.EstadoRepartidor(vistaHistorial.getEstado(), Integer.parseInt(id));

        } catch (Exception e) {

        }

    }

    private void AbrirVista(JFrame a, String titulo) {
        vistaMenu.setVisible(false);
        a.setTitle(titulo);
        a.setLocationRelativeTo(null);
        a.setVisible(true);

    }

    //Vista historial
    private void tituloTablaPedidos() {
        String titulo[] = {"Producto", "Tamaño", "Cantidad", "Total", "Fecha de envio", "Metod de envio", "Costo de envio"};
        tablaPedidos.setColumnIdentifiers(titulo);
        vistaHistorial.getTablaRepartidor().setModel(tablaPedidos);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == vistaPedidos.getEnviar()) {
            if (!"".equals(vistaPedidos.getMetodo().getText()) && !"".equals(vistaPedidos.getCosto().getText())) {
                String codigo = pediosMysql.CodigoPedidoRepartidorAsociado(id);
                pediosMysql.insertarEnvio(vistaPedidos.getMetodo().getText(), Double.parseDouble(vistaPedidos.getCosto().getText()), codigo);
                pediosMysql.ejecutarActualizacionEstado(codigo, "Enviado");
                JOptionPane.showMessageDialog(null, "Pedido completo");

                actualizarPedidosAsiganos();

            } else {
                JOptionPane.showMessageDialog(null, "Complete todo los campos");
            }
        }

        //Historial de pedidos
        if (ae.getSource() == vistaHistorial.getEstado()) {
            String estado = (String) vistaHistorial.getEstado().getSelectedItem();
            if (vistaHistorial.getEstado() != null) {
                tablaPedidos.setRowCount(0);
                pediosMysql.PedidosAñadidos(tablaPedidos, null, Integer.parseInt(id), pediosMysql.CodigoRepartido(id, estado), estado);
            }

        }
    }

    @Override
    public void mouseClicked(MouseEvent me) {

        //Viusta pedidos
        if (me.getSource() == vistaPedidos.getMenu()) {
            vistaPedidos.setVisible(false);
            AbrirVista(vistaMenu, "Menu");
        }

        if (me.getSource() == vistaHistorial.getMenu()) {
            vistaHistorial.setVisible(false);
            AbrirVista(vistaMenu, "Menu");
        }

    }

    @Override
    public void mousePressed(MouseEvent me) {

        {
            //llevar al login
            if (me.getSource() == vistaMenu.getCerrar()) {
                Vista.Login a = new Login();
                AbrirVista(a, "Login");

            }//llemar a vista comprar helado
            else if (me.getSource() == vistaMenu.getPedidosAsiganados()) {
                actualizarPedidosAsiganos();
                AbrirVista(vistaPedidos, "Pedidos asiganados");
            } else if (me.getSource() == vistaMenu.getHistorial()) {
                AbrirVista(vistaHistorial, "Historial");
                vistaHistorial.getEstado().setSelectedIndex(0);
                try {
                    pediosMysql.EstadoRepartidor(vistaHistorial.getEstado(), Integer.parseInt(id));

                } catch (Error e) {

                }

            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent me) {
    }

    @Override
    public void mouseEntered(MouseEvent me) {
    }

    @Override
    public void mouseExited(MouseEvent me) {
    }

}
