/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Contolador;

import static Contolador.ctrlUsuario.id;
import Modelo.InventarioBD;
import Modelo.PedidoBD;
import Modelo.Usuario;
import Modelo.UsuariosBD;
import Vista.ActualizarPerfil;
import Vista.Login;
import Vista.VistaMenuEmpleado;
import Vista.VistaUsuarios;
import Vista.vistaInventario;
import Vista.vistaPedidosEmpleado;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import Modelo.UsuariosBD;

/**
 *
 * @author WINDOWS 10
 */
public class ControladorEmpleado implements ActionListener, MouseListener {

    DefaultTableModel tabla;
    DefaultTableModel tablausuarios;
    private ActualizarPerfil vistaActualizar;
    private vistaPedidosEmpleado vistaPedido;
    private VistaUsuarios vistaUsuario;
    private VistaMenuEmpleado vistaMenu;
    private PedidoBD pedidosMysql;
    private vistaInventario vistaInventario;
    private InventarioBD invent;
    private UsuariosBD usuariosBd;

    private static ControladorEmpleado instancia;

    private ControladorEmpleado(VistaMenuEmpleado vistaMenuEM) {
        vistaMenu = vistaMenuEM;
        pedidosMysql = new PedidoBD();
        tabla = new DefaultTableModel();
        tablausuarios = new DefaultTableModel();

        vistaActualizar = new ActualizarPerfil();
        vistaPedido = new vistaPedidosEmpleado();
        vistaUsuario = new VistaUsuarios();
        vistaInventario = new vistaInventario();
        invent = new InventarioBD();
        usuariosBd = new UsuariosBD();
        añadirEscucha();
    }

    public static ControladorEmpleado obtenerInstancia(VistaMenuEmpleado vistaMenuEM) {
        if (instancia == null) {
            instancia = new ControladorEmpleado(vistaMenuEM);
        } else {
            instancia.reiniciarEscucha(vistaMenuEM);
        }
        return instancia;
    }

    private void añadirEscucha() {
        //Vista menu
        vistaMenu.getCerrar().addMouseListener(this);
        vistaMenu.getActualizar().addMouseListener(this);
        vistaMenu.getInventario().addMouseListener(this);
        vistaMenu.getProcesar().addMouseListener(this);

        //vista procesar pedidos
        vistaPedido.getAceptar().addActionListener(this);
        vistaPedido.getCancelar().addActionListener(this);
        vistaPedido.getRepartidoCombo().addActionListener(this);
        vistaPedido.getMenu().addMouseListener(this);
        vistaPedido.getActualizar().addMouseListener(this);

        //mostar inventario
        vistaInventario.getMenu().addMouseListener(this);
        vistaInventario.getBuscar().addActionListener(this);
        vistaInventario.getRestablecer().addActionListener(this);

        //usuarios
        vistaUsuario.getBuscar().addActionListener(this);
        vistaUsuario.getFiltrarEmpleado().addActionListener(this);
        vistaUsuario.getEliminar().addActionListener(this);
        vistaUsuario.getEditar().addActionListener(this);
        vistaUsuario.getMenu().addMouseListener(this);

        //editar usuario 
        vistaActualizar.getAceptar().addActionListener(this);
        vistaActualizar.getCancelar().addActionListener(this);
        usuariosBd.CargarTipoDeUsuarios(vistaActualizar.getTipoUsuario());

        titutloInventario();
        tiutloUsuarios();
    }

    public void reiniciarEscucha(VistaMenuEmpleado vistaMenuEM) {
        eliminarEscuchadores();
        vistaMenu = vistaMenuEM;
        vistaPedido = new vistaPedidosEmpleado();
        vistaUsuario = new VistaUsuarios();
        vistaInventario = new vistaInventario();
        vistaActualizar = new ActualizarPerfil();
        usuariosBd = new UsuariosBD();
        añadirEscucha();
    }

    private void eliminarEscuchadores() {
        for (MouseListener listener : vistaMenu.getCerrar().getMouseListeners()) {
            vistaMenu.getCerrar().removeMouseListener(listener);
        }
        for (MouseListener listener : vistaMenu.getActualizar().getMouseListeners()) {
            vistaMenu.getActualizar().removeMouseListener(listener);
        }
        for (MouseListener listener : vistaMenu.getInventario().getMouseListeners()) {
            vistaMenu.getInventario().removeMouseListener(listener);
        }
        for (MouseListener listener : vistaMenu.getProcesar().getMouseListeners()) {
            vistaMenu.getProcesar().removeMouseListener(listener);
        }
        for (ActionListener listener : vistaPedido.getAceptar().getActionListeners()) {
            vistaPedido.getAceptar().removeActionListener(listener);
        }
        for (ActionListener listener : vistaPedido.getCancelar().getActionListeners()) {
            vistaPedido.getCancelar().removeActionListener(listener);
        }
        for (ActionListener listener : vistaPedido.getRepartidoCombo().getActionListeners()) {
            vistaPedido.getRepartidoCombo().removeActionListener(listener);
        }
        for (ActionListener listener : vistaInventario.getBuscar().getActionListeners()) {
            vistaInventario.getBuscar().removeActionListener(listener);
        }
        for (ActionListener listener : vistaInventario.getRestablecer().getActionListeners()) {
            vistaInventario.getRestablecer().removeActionListener(listener);
        }
        for (ActionListener listener : vistaUsuario.getBuscar().getActionListeners()) {
            vistaUsuario.getBuscar().removeActionListener(listener);
        }
        for (ActionListener listener : vistaUsuario.getFiltrarEmpleado().getActionListeners()) {
            vistaUsuario.getFiltrarEmpleado().removeActionListener(listener);
        }
        for (ActionListener listener : vistaUsuario.getEliminar().getActionListeners()) {
            vistaUsuario.getEliminar().removeActionListener(listener);
        }
        for (ActionListener listener : vistaUsuario.getEditar().getActionListeners()) {
            vistaUsuario.getEditar().removeActionListener(listener);
        }

        for (ActionListener listener : vistaActualizar.getAceptar().getActionListeners()) {
            vistaActualizar.getAceptar().removeActionListener(listener);
        }
        for (ActionListener listener : vistaActualizar.getCancelar().getActionListeners()) {
            vistaActualizar.getCancelar().removeActionListener(listener);
        }
    }

    private void restablecerVistaUsuario() {

        try {
            usuariosBd.CargarTipoDeUsuarios(vistaUsuario.getFiltrarEmpleado());
            usuariosBd.mostrarTodos(tablausuarios);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void titutloInventario() {
        String titulo[] = {"Codigo", "Nombre", "Tamaño", "Precio"};
        tabla.setColumnIdentifiers(titulo);
        vistaInventario.getTablaInventario().setModel(tabla);
    }

    private void tiutloUsuarios() {
        String titulo[] = {"Id", "Usuario", "Nombre Completo", "Email", "Tipo Usuario", "Contraseña"};
        tablausuarios.setColumnIdentifiers(titulo);
        vistaUsuario.getTablaUsuarios().setModel(tablausuarios);
    }

    private void AbrirVista(JFrame a, String titulo) {
        vistaMenu.setVisible(false);
        a.setTitle(titulo);
        a.setLocationRelativeTo(null);
        a.setVisible(true);

    }

    private void acttualizarPedidos() {
        try {
            vistaPedido.getTotal().setText("Pedidos pendientes: " + pedidosMysql.ContarPedidos());
            vistaPedido.getAreaPedidos().setText(pedidosMysql.pedidosPendientes());
            vistaPedido.getRepartidoCombo().setSelectedIndex(0);
            pedidosMysql.AñadirRepartidor(vistaPedido.getRepartidoCombo());
            vistaPedido.getButtonGroup1().clearSelection();
        } catch (Exception e) {

        }
    }
//Vista ver invetario

    private void restablecer() {
        vistaInventario.getCodigo().setText("");
        tabla.setRowCount(0);
        try {
            tabla.setRowCount(0);
            invent.mostrarDatos(tabla, "");

        } catch (Exception e) {

        }
    }
//Vista editar usuario

    private void cargarDatosEnvistaEditar(int id) {
        JOptionPane.showMessageDialog(null, "Cargando datos.");

        ArrayList<String[]> datosUsuario = usuariosBd.mostrarDatosPorId(id);
        if (!datosUsuario.isEmpty()) {
            for (String[] datos : datosUsuario) {
                vistaActualizar.getTxtUsuario().setText(datos[1]);
                vistaActualizar.getTxtNNombre().setText(datos[2]);
                vistaActualizar.getTxtCorreo().setText(datos[3]);
                vistaActualizar.getTipoUsuario().setSelectedItem(datos[4]);
                vistaActualizar.getTxtContraseña().setText(datos[5]);

            }
        } else {
            JOptionPane.showMessageDialog(null, "No se encontraron resultados para el ID proporcionado.");
        }

    }

    public Usuario extraerDatosDesdeVista() throws Exception {
        StringBuilder errores = new StringBuilder();
        Usuario usuario = new Usuario();
        if (vistaActualizar.getTxtUsuario().getText().trim().isEmpty()) {
            errores.append("- El campo 'Nombre de Usuario' no puede estar vacío.\n");
        }
        if (vistaActualizar.getTxtNNombre().getText().trim().isEmpty()) {
            errores.append("- El campo 'Nombre Completo' no puede estar vacío.\n");
        }
        if (vistaActualizar.getTxtCorreo().getText().trim().isEmpty()) {
            errores.append("- El campo 'Correo' no puede estar vacío.\n");
        }
        if (vistaActualizar.getTxtContraseña().getText().trim().isEmpty()) {
            errores.append("- El campo 'Contraseña' no puede estar vacío.\n");
        }
        String tipoUsuario = vistaActualizar.getTipoUsuario().getSelectedItem().toString();
        if (tipoUsuario.equalsIgnoreCase("Seleccione") || tipoUsuario.equalsIgnoreCase("Todos")) {
            errores.append("- Debe seleccionar un tipo de usuario válido.\n");
        }

        // Si hay errores, lanzar excepción con todos los mensajes acumulados
        if (errores.length() > 0) {
            JOptionPane.showMessageDialog(null, errores.toString());
            return null;
        }

        // Asignar valores si no hay errores
        usuario.setNombreUsuario(vistaActualizar.getTxtUsuario().getText().trim());
        usuario.setNombreCompleto(vistaActualizar.getTxtNNombre().getText().trim());
        usuario.setEmail(vistaActualizar.getTxtCorreo().getText().trim());
        usuario.setTipoUsuario(tipoUsuario);
        usuario.setContrasena(vistaActualizar.getTxtContraseña().getText().trim());

        return usuario;
    }

    public void limpiarCamposUsuario() {
        vistaActualizar.getTxtUsuario().setText("");
        vistaActualizar.getTxtNNombre().setText("");
        vistaActualizar.getTxtCorreo().setText("");
        vistaActualizar.getTxtContraseña().setText("");
        vistaActualizar.getTipoUsuario().setSelectedIndex(0);
    }

    //
    @Override
    public void actionPerformed(ActionEvent ae) {

        if (vistaPedido.getAceptar().isSelected()) {

            String escogio = (String) vistaPedido.getRepartidoCombo().getSelectedItem();
            if (escogio != null) {
                if (!escogio.equals("Seleccione")) {
                    String codigo = pedidosMysql.idUltimoPedido();
                    pedidosMysql.ejecutarActualizacionEstado(codigo, "Aceptado");
                    pedidosMysql.actualizarRepartidor(codigo, pedidosMysql.obtenerIdUsuarioPorNombre(escogio));
                    JOptionPane.showMessageDialog(null, "Pedido Asignado con exito");
                    acttualizarPedidos();

                } else {
                    JOptionPane.showMessageDialog(null, "Seleccione repartidor");

                }
            }
        } else if (vistaPedido.getCancelar().isSelected()) {
            String codigo = pedidosMysql.idUltimoPedido();
            pedidosMysql.ejecutarActualizacionEstado(codigo, "Cancelado");
            JOptionPane.showMessageDialog(null, "Pedido cancelado con exito");
            acttualizarPedidos();
        }

        //vista inventario
        if (ae.getSource() == vistaInventario.getRestablecer()) {
            restablecer();
        } else if (ae.getSource() == vistaInventario.getBuscar()) {
            //validar que no este vacio
            if (!vistaInventario.getCodigo().getText().equals("")) {
                String codigo = "";
                try {
                    codigo = vistaInventario.getCodigo().getText();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Ingrese un valor numerico");

                }
                try {
                    tabla.setRowCount(0);
                    invent.mostrarDatos(tabla, codigo);
                    if (tabla.getRowCount() < 1) {
                        JOptionPane.showMessageDialog(null, "No hay resultados...");
                        tabla.setRowCount(0);

                    }
                } catch (Exception e) {

                }
            } else {
                JOptionPane.showMessageDialog(null, "Ingrese un codigo para buscar");

            }
        }

        //vista usuario
        if (ae.getSource() == vistaUsuario.getBuscar()) {
            int cedula = 0;
            try {
                try {
                    cedula = Integer.parseInt(vistaUsuario.getCedula().getText());
                    JOptionPane.showMessageDialog(null, "Buscando");
                    tablausuarios.setRowCount(0);
                    usuariosBd.mostrarPorCedula(tablausuarios, cedula);
                    vistaUsuario.getFiltrarEmpleado().setSelectedIndex(0);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Ingrese un valor numerico");
                }

            } catch (Exception e) {
            }
        } else if (ae.getSource() == vistaUsuario.getFiltrarEmpleado()) {
            if (vistaUsuario.getFiltrarEmpleado().getSelectedIndex() > 0) {
                vistaUsuario.getCedula().setText("");
                String estado = (String) vistaUsuario.getFiltrarEmpleado().getSelectedItem();
                if (vistaUsuario.getFiltrarEmpleado().getSelectedIndex() == 1) {
                    tablausuarios.setRowCount(0);
                    usuariosBd.mostrarTodos(tablausuarios);
                } else {
                    tablausuarios.setRowCount(0);

                    usuariosBd.mostrarPorTipoUsuario(tablausuarios, estado);
                }
            }
        } else if (ae.getSource() == vistaUsuario.getEliminar()) {
            int fila = vistaUsuario.getTablaUsuarios().getSelectedRow();
            if (fila != -1) {
                int id = Integer.parseInt(tablausuarios.getValueAt(fila, 0).toString());
                usuariosBd.eliminarUsuarioPorId(id);
                usuariosBd.mostrarTodos(tablausuarios);
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione id de usuario a eliminar");
            }
        } else if (ae.getSource() == vistaUsuario.getEditar()) {
            int fila = vistaUsuario.getTablaUsuarios().getSelectedRow();
            if (fila != -1) {
                idMoficar = Integer.parseInt(tablausuarios.getValueAt(fila, 0).toString());
                AbrirVista(vistaActualizar, "Editar datos del usuario");
                limpiarCamposUsuario();
                cargarDatosEnvistaEditar(idMoficar);

            } else {
                JOptionPane.showMessageDialog(null, "Seleccione id de usuario a editar");
            }
        } //Vista editar usaurio
        else if (ae.getSource() == vistaActualizar.getCancelar()) {
            vistaActualizar.setVisible(false);
        } else if (ae.getSource() == vistaActualizar.getAceptar()) {
            try {
                Usuario objeto = extraerDatosDesdeVista();
                if (objeto != null) {
                    usuariosBd.actualizarUsuario(idMoficar, extraerDatosDesdeVista());
                    tablausuarios.setRowCount(0);
                    usuariosBd.mostrarTodos(tablausuarios);
                    vistaActualizar.setVisible(false);
                }
            } catch (Exception ex) {
            }

        }

    }
    private int idMoficar = 0;

    @Override
    public void mouseClicked(MouseEvent me) {

        //menu
        {
            //llevar al login
            if (me.getSource() == vistaMenu.getCerrar()) {
                Vista.Login a = new Login();
                AbrirVista(a, "Login");

            }//llemar a vista comprar helado
            else if (me.getSource() == vistaMenu.getProcesar()) {
                AbrirVista(vistaPedido, "Procesar pedidos");
                try {
                    pedidosMysql.AñadirRepartidor(vistaPedido.getRepartidoCombo());

                    acttualizarPedidos();
                } catch (Exception e) {
                }
            }//llevar a ver pedidos
            else if (me.getSource() == vistaMenu.getInventario()) {
                AbrirVista(vistaInventario, "Inventario");
                restablecer();
            } else if (me.getSource() == vistaMenu.getActualizar()) {
                tablausuarios.setRowCount(0);
                AbrirVista(vistaUsuario, "usuarios");
                restablecerVistaUsuario();

                //    vistaVerPedi.getJcomboxOpciones().setSelectedIndex(0);
            }

        }

    }

    @Override
    public void mousePressed(MouseEvent me) {
        if (me.getSource() == vistaPedido.getMenu()) {
            vistaPedido.setVisible(false);
            AbrirVista(vistaMenu, "Menu");
        } else if (me.getSource() == vistaPedido.getActualizar()) {
            acttualizarPedidos();
        }

        //vista pedido
        if (me.getSource() == vistaUsuario.getMenu()) {
            vistaUsuario.setVisible(false);
            AbrirVista(vistaMenu, "Menu");
        }
        //vista pedido
        if (me.getSource() == vistaInventario.getMenu()) {
            vistaInventario.setVisible(false);
            AbrirVista(vistaMenu, "Menu");
        }

    }

    @Override
    public void mouseReleased(MouseEvent me) {
    }

    @Override
    public void mouseEntered(MouseEvent me) {
    }

    @Override
    public void mouseExited(MouseEvent me) {
    }

}
