package Contolador;

import Conector.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ctrlUsuario {
    private final Conexion cx;
    private Connection conn;

    public ctrlUsuario() {
        cx = new Conexion();
        conn = cx.getConnection();
    }
public static String id;
    public String obtenerTipoUsuario(String usuario, String contrasena) {
        if (conn == null) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        try {
            String sql = "SELECT `id_usuario`, `tipo_usuario` FROM usuarios WHERE nombre_usuario = ? AND contrasena_usuario = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, contrasena);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                id=rs.getString("id_usuario");
                return rs.getString("tipo_usuario"); // Retorna el tipo de usuario si las credenciales son correctas
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error de base de datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return null; // Retorna null si las credenciales no son válidas o si ocurre un error
    }

    // Método para cerrar la conexión (puedes llamar a este método cuando sea necesario)
    public void cerrarConexion() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}