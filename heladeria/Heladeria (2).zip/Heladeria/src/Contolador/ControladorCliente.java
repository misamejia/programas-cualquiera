/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Contolador;

import static Contolador.ctrlUsuario.id;
import Modelo.Pedido;
import Modelo.PedidoBD;
import Vista.Login;
import Vista.VistaCompraClientes;
import Vista.VistaRealizarPedido;
import Vista.VistaVerPedidos;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author WINDOWS 10
 */
public class ControladorCliente implements ActionListener, MouseListener {

    DefaultTableModel tabla;
    DefaultTableModel tablaPedidos;
    private Vista.VistaCompraClientes vistaComprClie;
    private VistaRealizarPedido vistaRealizar;
    private PedidoBD PedidosMysq;
    private VistaVerPedidos vistaVerPedi;

// Instancia privada estática de la clase ControladorCliente
    private static ControladorCliente instancia;

    private ControladorCliente(VistaCompraClientes a) {
        // Crear objetos
        vistaComprClie = a;
        PedidosMysq = new PedidoBD();
        tabla = new DefaultTableModel();
        vistaVerPedi = new VistaVerPedidos();
        vistaRealizar = new VistaRealizarPedido();
        añadirEscucha();
        añadirEscuchaComprarHelado();
        añadirEscuhaVerPedido();
    }

    // Método público estático para obtener la instancia única de la clase
    public static ControladorCliente obtenerInstancia(VistaCompraClientes a) {
        // Si no existe la instancia, se crea
        if (instancia == null) {
            instancia = new ControladorCliente(a);
        } else {
            instancia.reiniciarEscucha(a);
        }
        // Si ya existe, se devuelve la instancia previamente creada
        return instancia;
    }

    private void tituloCompra() {
        String titulo[] = {"Producto", "Tamaño", "Cantidad", "Total"};
        tabla.setColumnIdentifiers(titulo);
        vistaRealizar.getTablaPedidos().setModel(tabla);
    }

    private void añadirEscucha() {
        vistaComprClie.getLablerRealizarCompra().addMouseListener(this);
        vistaComprClie.getLaberlCerraSesion().addMouseListener(this);
        vistaComprClie.getLablerVerPedido().addMouseListener(this);
    }

    private void añadirEscuchaComprarHelado() {
        //Escucha para botones de vista realizar pedidos
        PedidosMysq.cargarSabores(vistaRealizar.getJtipo());
        vistaRealizar.getJtipo().addActionListener(this);
        vistaRealizar.getJtamaño().addActionListener(this);
        vistaRealizar.getBAñadir().addActionListener(this);
        vistaRealizar.getTablaPedidos().addMouseListener(this);
        vistaRealizar.getMenu().addMouseListener(this);
        vistaRealizar.getBEliminar().addActionListener(this);
        vistaRealizar.getChCancelar().addActionListener(this);
        vistaRealizar.getChConfirmar().addActionListener(this);
        SpinnerNumberModel model = new SpinnerNumberModel(0, 0, 100, 1);
        vistaRealizar.getScantidad().setModel(model);
        tituloCompra();
        try {
            PedidosMysq.PedidosAñadidos(tabla, Integer.parseInt(id), null, PedidosMysq.GenerarCodigo(id, "En Carrito"), "En carrito");
            vistaRealizar.getTotal().setText("Valor total del pedido : " + PedidosMysq.obtenerSumaTotal(Integer.parseInt(id), PedidosMysq.GenerarCodigo(id, "En carrito")));

        } catch (Exception e) {

        }
    }

    public void reiniciarEscucha(VistaCompraClientes vistaCompraClientes) {
        eliminarEscuchadores();
        vistaComprClie = vistaCompraClientes;
        vistaVerPedi = new VistaVerPedidos();
        vistaRealizar = new VistaRealizarPedido();
        PedidosMysq = new PedidoBD();
        añadirEscucha();
        añadirEscuchaComprarHelado();
        añadirEscuhaVerPedido();
    }

    private void eliminarEscuchadores() {
        // Eliminar MouseListeners de vistaComprClie
        for (MouseListener listener : vistaComprClie.getLablerRealizarCompra().getMouseListeners()) {
            vistaComprClie.getLablerRealizarCompra().removeMouseListener(listener);
        }
        for (MouseListener listener : vistaComprClie.getLaberlCerraSesion().getMouseListeners()) {
            vistaComprClie.getLaberlCerraSesion().removeMouseListener(listener);
        }
        for (MouseListener listener : vistaComprClie.getLablerVerPedido().getMouseListeners()) {
            vistaComprClie.getLablerVerPedido().removeMouseListener(listener);
        }

        // Eliminar ActionListeners de vistaRealizar
        for (ActionListener listener : vistaRealizar.getJtipo().getActionListeners()) {
            vistaRealizar.getJtipo().removeActionListener(listener);
        }
        for (ActionListener listener : vistaRealizar.getJtamaño().getActionListeners()) {
            vistaRealizar.getJtamaño().removeActionListener(listener);
        }
        for (ActionListener listener : vistaRealizar.getBAñadir().getActionListeners()) {
            vistaRealizar.getBAñadir().removeActionListener(listener);
        }
        for (ActionListener listener : vistaRealizar.getBEliminar().getActionListeners()) {
            vistaRealizar.getBEliminar().removeActionListener(listener);
        }
        for (ActionListener listener : vistaRealizar.getChCancelar().getActionListeners()) {
            vistaRealizar.getChCancelar().removeActionListener(listener);
        }
        for (ActionListener listener : vistaRealizar.getChConfirmar().getActionListeners()) {
            vistaRealizar.getChConfirmar().removeActionListener(listener);
        }

        // Eliminar MouseListeners de vistaRealizar
        for (MouseListener listener : vistaRealizar.getTablaPedidos().getMouseListeners()) {
            vistaRealizar.getTablaPedidos().removeMouseListener(listener);
        }
        for (MouseListener listener : vistaRealizar.getMenu().getMouseListeners()) {
            vistaRealizar.getMenu().removeMouseListener(listener);
        }
    }

//id_cliente, fecha_pedido, total, estado, id_helado,codigoGrupo,cantidad) 
    private Pedido ObtenerDatos() {
        if (vistaRealizar.getJtipo().getSelectedItem().equals("Seleccione")
                || vistaRealizar.getJtamaño().getSelectedItem().equals("Seleccione")
                || (int) vistaRealizar.getScantidad().getValue() <= 0) {
            JOptionPane.showMessageDialog(null, "Datos Incompletos");
            return null;
        }
        Pedido ped = new Pedido();
        ped.setId_cliente(Integer.parseInt(id));
        ped.CodigoGrupo = PedidosMysq.GenerarCodigo(id, "En Carrito");
        ped.setCantidad((int) vistaRealizar.getScantidad().getValue());
        String sabor = (String) vistaRealizar.getJtipo().getSelectedItem();
        String tipo = (String) vistaRealizar.getJtamaño().getSelectedItem();
        ped.setId_helado(PedidosMysq.obtenerCodigoDelHelado(sabor, tipo));
        ped.setTamaño(tipo);
        return ped;
    }

    private void limpiarCamposCompra() {
        vistaRealizar.getJtipo().setSelectedIndex(0);
        //scantida es un espiner 
        vistaRealizar.getScantidad().setValue(0);
        tabla.setRowCount(0);
        vistaRealizar.getButtonGroup1().clearSelection();
        try {
            PedidosMysq.PedidosAñadidos(tabla, Integer.parseInt(id), null, PedidosMysq.GenerarCodigo(id, "En Carrito"), "En carrito");
            vistaRealizar.getTotal().setText("Valor total del pedido : " + PedidosMysq.obtenerSumaTotal(Integer.parseInt(id), PedidosMysq.GenerarCodigo(id, "En carrito")));

        } catch (Exception e) {

        }

    }

    //Cerrar sesion
    private void AbrirVista(JFrame a, String titulo) {
        vistaComprClie.setVisible(false);
        a.setTitle(titulo);
        a.setLocationRelativeTo(null);
        a.setVisible(true);

    }

    //ver pedidos
    private void añadirEscuhaVerPedido() {
        vistaVerPedi.getLaberPMenu().addMouseListener(this);
        vistaVerPedi.getJcomboxOpciones().addActionListener(this);
        tablaPedidos = new DefaultTableModel();
        tituloTablaPedidos();
        PedidosMysq.EstadosPedidoPorID(vistaVerPedi.getJcomboxOpciones(), Integer.parseInt(id));
    }

    private void tituloTablaPedidos() {
        String titulo[] = {"Producto", "Tamaño", "Cantidad", "Total", "Fecha de envio", "Metod de envio", "Costo de envio"};
        tablaPedidos.setColumnIdentifiers(titulo);
        vistaVerPedi.getTablaVerPedidos().setModel(tablaPedidos);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

        //accions para realizar pedido
        //añadir pedido
        if (ae.getSource() == vistaRealizar.getBAñadir()) {
            if (ObtenerDatos() != null) {
                PedidosMysq.añadirPedido(ObtenerDatos());
                limpiarCamposCompra();
            }
        }
        //cargar el tamaño en base al tipo de helado
        if (ae.getSource() == vistaRealizar.getJtipo()) {
            PedidosMysq.actualizarTamanos(vistaRealizar.getJtipo(), vistaRealizar.getJtamaño());
        }

        //eliminar pedido espeficico
        if (ae.getSource() == vistaRealizar.getBEliminar()) {
            int fila = vistaRealizar.getTablaPedidos().getSelectedRow();
            if (fila != -1) {
                String nombre = (tabla.getValueAt(fila, 0).toString());
                String tamaño = (tabla.getValueAt(fila, 1).toString());
                int codigo = PedidosMysq.obtenerCodigoDelHelado(nombre, tamaño);
                String codigoGrupo = PedidosMysq.GenerarCodigo(id, "En Carrito");
                int codigoPedido = PedidosMysq.obtenerCodigoDelPedido(codigo, codigoGrupo);
                PedidosMysq.eliminarPedido(codigoPedido);
                limpiarCamposCompra();
            } else {
                JOptionPane.showMessageDialog(null, "Seleccion un producto de la tabla para eliminar");
            }
        }

        //cancelar pedido
        if (vistaRealizar.getChCancelar().isSelected()) {
            String codigo = PedidosMysq.GenerarCodigo(id, "En Carrito");
            if (codigo != null) {
                PedidosMysq.cancelarPedido(codigo);
                limpiarCamposCompra();
            } else {
                JOptionPane.showMessageDialog(null, "No Cuenta con pedidos actualmente ");

            }

        }
        //confirmar pedido
        if (vistaRealizar.getChConfirmar().isSelected()) {
            String codigo = PedidosMysq.GenerarCodigo(id, "En Carrito");
            if (codigo != null) {
                PedidosMysq.ejecutarActualizacionEstado(codigo, "Pendiente");
                JOptionPane.showMessageDialog(null, "Pedido Solicitado con exito");
                limpiarCamposCompra();
            } else {
                JOptionPane.showMessageDialog(null, "No Cuenta con pedidos actualmente ");

            }
        }

        //vista ver pedidos
        if (ae.getSource() == vistaVerPedi.getJcomboxOpciones()) {
            String estado = (String) vistaVerPedi.getJcomboxOpciones().getSelectedItem();
            if (vistaVerPedi.getJcomboxOpciones() != null) {
                tablaPedidos.setRowCount(0);
                PedidosMysq.PedidosAñadidos(tablaPedidos, Integer.parseInt(id), null, PedidosMysq.GenerarCodigo(id, estado), estado);
            }

        }
    }

    @Override
    public void mouseClicked(MouseEvent me
    ) {
    }

    @Override
    public void mousePressed(MouseEvent me
    ) {

        //Controlador para el Menu
        {
            //llevar al login
            if (me.getSource() == vistaComprClie.getLaberlCerraSesion()) {
                Vista.Login a = new Login();
                AbrirVista(a, "Login");
            }//llemar a vista comprar helado
            else if (me.getSource() == vistaComprClie.getLablerRealizarCompra()) {
                AbrirVista(vistaRealizar, "Comprar");
            }//llevar a ver pedidos
            else if (me.getSource() == vistaComprClie.getLablerVerPedido()) {
                AbrirVista(vistaVerPedi, "Pedidos");
                PedidosMysq.EstadosPedidoPorID(vistaVerPedi.getJcomboxOpciones(), Integer.parseInt(id));

                vistaVerPedi.getJcomboxOpciones().setSelectedIndex(0);
            }

        }

        //realizar pedido
        {
            if (me.getSource() == vistaRealizar.getMenu()) {
                vistaRealizar.dispose();
                vistaComprClie.setVisible(true);

            }
            {
                if (me.getSource() == vistaVerPedi.getLaberPMenu()) {
                    vistaVerPedi.setVisible(false);
                    vistaComprClie.setVisible(true);

                }
            }
        }

    }

    @Override
    public void mouseReleased(MouseEvent me
    ) {
    }

    @Override
    public void mouseEntered(MouseEvent me
    ) {
    }

    @Override
    public void mouseExited(MouseEvent me
    ) {
    }

}
