package Vista;

import javax.swing.*;
import java.awt.*;

public class Empleado extends JFrame {

    public Empleado() {
        initComponents();
        this.setTitle("Panel de Empleado");
        this.setSize(700, 500);
        this.setLocationRelativeTo(null); // Centrar en la pantalla
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void initComponents() {
        // Crear componentes
        JLabel lblWelcome = new JLabel("Bienvenido, Empleado");
        lblWelcome.setFont(new Font("Arial", Font.BOLD, 24));
        
        JButton btnProcessOrders = new JButton("Procesar Pedidos");
        JButton btnCheckInventory = new JButton("Ver Inventario");
        JButton btnUpdateProfile = new JButton("Actualizar Perfil");
        JButton btnLogout = new JButton("Cerrar Sesión");

        // Agregar acciones a los botones
        btnProcessOrders.addActionListener(evt -> processOrders());
        btnCheckInventory.addActionListener(evt -> checkInventory());
        btnUpdateProfile.addActionListener(evt -> updateProfile());
        btnLogout.addActionListener(evt -> logout());

        // Crear un panel y agregar componentes
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1, 10, 10)); // 5 filas, 1 columna
        panel.add(lblWelcome);
        panel.add(btnProcessOrders);
        panel.add(btnCheckInventory);
        panel.add(btnUpdateProfile);
        panel.add(btnLogout);

        // Agregar el panel a la ventana
        this.getContentPane().add(panel);
    }

    private void processOrders() {
        // Lógica para procesar pedidos
        JOptionPane.showMessageDialog(this, "Funcionalidad para procesar pedidos.");
    }

    private void checkInventory() {
        // Lógica para ver inventario
        JOptionPane.showMessageDialog(this, "Funcionalidad para ver inventario.");
    }

    private void updateProfile() {
        // Lógica para actualizar perfil del empleado
        JOptionPane.showMessageDialog(this, "Funcionalidad para actualizar perfil.");
    }

    private void logout() {
        // Lógica para cerrar sesión y volver a la pantalla de login
        new Login().setVisible(true);
        this.dispose(); // Cerrar la ventana de empleado
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            new Empleado().setVisible(true);
        });
    }
}
