package Vista;

import Modelo.Helado;
import Modelo.Pedido;
import java.util.ArrayList;
import java.util.List;

class Heladeria {
    private final List<Helado> heladosDisponibles;
    private final List<Pedido> pedidos;

    public Heladeria() {
        heladosDisponibles = new ArrayList<>();
        pedidos = new ArrayList<>();
    }

    public void agregarHeladoDisponible(Helado helado) {
        heladosDisponibles.add(helado);
    }

    public void realizarPedido(Pedido pedido) {
        pedidos.add(pedido);
    }

    public List<Helado> getHeladosDisponibles() {
        return heladosDisponibles;
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    @Override
    public String toString() {
        return "Heladería con " + heladosDisponibles.size() + " helados disponibles y " + pedidos.size() + " pedidos realizados.";
    }
}

