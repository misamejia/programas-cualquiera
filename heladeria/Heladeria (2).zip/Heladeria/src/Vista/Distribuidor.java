/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Vista.Login;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Distribuidor extends JFrame {
    
    public Distribuidor() {
        setTitle("Distribuidor");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));

        JButton btnVerPedidos = new JButton("Ver Pedidos");
        JButton btnActualizarInventario = new JButton("Actualizar Inventario");
        JButton btnGestionarDistribucion = new JButton("Gestionar Distribución");
        JButton btnCerrarSesion = new JButton("Cerrar Sesión");

        btnVerPedidos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                verPedidos();
            }
        });

        btnActualizarInventario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarInventario();
            }
        });

        btnGestionarDistribucion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gestionarDistribucion();
            }
        });

        btnCerrarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cerrarSesion();
            }
        });

        panel.add(btnVerPedidos);
        panel.add(btnActualizarInventario);
        panel.add(btnGestionarDistribucion);
        panel.add(btnCerrarSesion);

        add(panel);
    }

    private void verPedidos() {
        // Lógica para ver pedidos
        JOptionPane.showMessageDialog(this, "Funcionalidad para ver pedidos.");
    }

    private void actualizarInventario() {
        // Lógica para actualizar inventario
        JOptionPane.showMessageDialog(this, "Funcionalidad para actualizar inventario.");
    }

    private void gestionarDistribucion() {
        // Lógica para gestionar distribución
        JOptionPane.showMessageDialog(this, "Funcionalidad para gestionar distribución.");
    }

    private void cerrarSesion() {                                             
        int confirmacion = JOptionPane.showConfirmDialog(this, 
            "¿Estás seguro de que deseas cerrar sesión?", 
            "Confirmar Cierre de Sesión", 
            JOptionPane.YES_NO_OPTION);

    if (confirmacion == JOptionPane.YES_OPTION) {
        // Si se confirma, cerrar la ventana actual
        this.dispose(); // Cierra la ventana actual

        Login loginVentana = new Login(); // Asegúrate de que el nombre de la clase es correcto
        loginVentana.setVisible(true); // Hacer visible la ventana de login
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Distribuidor distribuidor = new Distribuidor();
            distribuidor.setVisible(true);
        });
    }
}

