package Vista;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class FacturaGUI extends JFrame {
    
    public FacturaGUI(List<String> productos, double precioTotal) {
        setTitle("Factura de Pedido");
        setSize(400, 600);
        setLocationRelativeTo(null);  // Centra la ventana en la pantalla
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        add(panel);
        
        JLabel lblTitulo = new JLabel("Factura de Pedido", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
        panel.add(lblTitulo);
        
        // Mostrar los productos
        JTextArea textoFactura = new JTextArea();
        textoFactura.setEditable(false);
        textoFactura.setFont(new Font("Arial", Font.PLAIN, 16));
        
        // Agregar los productos a la factura
        for (String item : productos) {
            textoFactura.append(item + "\n");
        }
        
        // Agregar el precio total
        textoFactura.append("====================================\n");
        textoFactura.append(String.format("Total: $%.2f\n", precioTotal));
        textoFactura.append("====================================\n");
        textoFactura.append("Gracias por tu compra!\n");
        
        panel.add(new JScrollPane(textoFactura));
        
        setVisible(true);
    }
}
