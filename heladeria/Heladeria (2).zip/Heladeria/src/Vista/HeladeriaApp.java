package Vista;

import Conector.Conexion;
import static Contolador.ctrlUsuario.id;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import java.awt.*;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HeladeriaApp extends JFrame {

    private JComboBox<String> comboSabor;
    private JComboBox<String> comboTamaño;
    private JLabel lblPrecio;
    private JSpinner spnCantidad;
    private JButton btnAgregar;
    private JButton btnEliminar;
    private JList<String> listaPedido;
    private DefaultListModel<String> modeloPedido;
    private ArrayList<String> codi = new ArrayList<>();
    private int idH;

    //al incio se genera un codigo
    private String codigoGrupo = generarCodigo();

    public HeladeriaApp() {
        setTitle("Heladería");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 600);
        setLocationRelativeTo(null);  // Centra la ventana en la pantalla

        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 1, 10, 10));  // Aumentado el número de filas para incluir el nuevo botón
        add(panel);

        // Logo de la heladería
        JLabel lblLogo = new JLabel(new ImageIcon(getClass().getResource("/icon/logo.png")));
        panel.add(lblLogo);

        // Nombre de la heladería
        JLabel lblNombre = new JLabel("Heladería ICE DREAM", SwingConstants.CENTER);
        lblNombre.setFont(new Font("Arial", Font.BOLD, 24));
        panel.add(lblNombre);

        // Selección de sabor
        JLabel lblSabor = new JLabel("Selecciona el sabor:");
        comboSabor = new JComboBox<>();
        panel.add(lblSabor);
        panel.add(comboSabor);

        // Selección de tamaño
        JLabel lblTamaño = new JLabel("Selecciona el tamaño:");
        comboTamaño = new JComboBox<>();
        panel.add(lblTamaño);
        panel.add(comboTamaño);

        // Mostrar el precio
        lblPrecio = new JLabel("Precio: $0.00");
        panel.add(lblPrecio);

        // Selección de cantidad
        JLabel lblCantidad = new JLabel("Cantidad:");
        spnCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        panel.add(lblCantidad);
        panel.add(spnCantidad);

        // Botón para agregar al pedido
        btnAgregar = new JButton("Agregar al pedido");
        panel.add(btnAgregar);

        // Listado del pedido
        modeloPedido = new DefaultListModel<>();
        listaPedido = new JList<>(modeloPedido);
        JScrollPane scrollPane = new JScrollPane(listaPedido);
        panel.add(scrollPane);

        // Botones de confirmación y cancelación
        JButton btnConfirmar = new JButton("Confirmar pedido");
        JButton btnCancelar = new JButton("Cancelar pedido");
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnConfirmar);
        panelBotones.add(btnCancelar);
        panel.add(panelBotones);

        // Botón para eliminar producto
        btnEliminar = new JButton("Eliminar producto");
        panel.add(btnEliminar);

        // Cargar los sabores desde la base de datos al iniciar la app
        cargarSabores();
        btnConfirmar.addActionListener(e -> {
            if (modeloPedido.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No has agregado productos al pedido.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            codi.clear();
            double precioTotal = 0.0;
            List<String> productos = new ArrayList<>();

            for (int i = 0; i < modeloPedido.size(); i++) {
                String item = modeloPedido.getElementAt(i).trim();

                // Extraer el nombre completo del producto, tamaño y cantidad
                int indiceParentesisApertura = item.lastIndexOf("(");
                int indiceParentesisCierre = item.lastIndexOf(")");
                int indiceCantidad = item.lastIndexOf("x"); // Buscar el "x" antes de la cantidad

                if (indiceParentesisApertura == -1 || indiceParentesisCierre == -1 || indiceParentesisCierre < indiceParentesisApertura || indiceCantidad == -1) {
                    JOptionPane.showMessageDialog(this, "Error en el formato del producto: " + item, "Error", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Extraer el nombre del sabor
                String sabor = item.substring(0, indiceParentesisApertura).trim();
                // Extraer el tamaño del producto
                String tamaño = item.substring(indiceParentesisApertura + 1, indiceParentesisCierre).trim();
                // Extraer la cantidad
                int cantidad = Integer.parseInt(item.substring(indiceCantidad + 1).trim());

                // Obtener el precio
                double precioUnitario = obtenerPrecio(sabor, tamaño);
                idH = obtenerCodigo(sabor, tamaño);
                double totalItem = precioUnitario * cantidad;

                // Agregar el producto a la lista
                productos.add(String.format("%s %s x%d: $%.2f", sabor, tamaño, cantidad, totalItem));
                precioTotal += totalItem;
            }

            JOptionPane.showMessageDialog(this, "Pedido confirmado con ID: ");
            codigoGrupo = generarCodigo();

            new FacturaGUI(productos, precioTotal);

            modeloPedido.clear();
            comboSabor.setSelectedIndex(-1);
            comboTamaño.setSelectedIndex(-1);
            spnCantidad.setValue(1);

        }
        );

        btnCancelar.addActionListener(e
                -> {
            int opcion = JOptionPane.showConfirmDialog(this, "¿Estás seguro de cancelar el pedido?", "Cancelar Pedido", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {

                if (!modeloPedido.isEmpty()) {
                    cancelarPedido(codigoGrupo);
                    codigoGrupo = generarCodigo();
                    codi.clear();

                }

                modeloPedido.clear();
                lblPrecio.setText("Precio: $0.00");
                comboSabor.setSelectedIndex(-1);
                comboTamaño.setSelectedIndex(-1);
                spnCantidad.setValue(1);

            }
        }
        );

        // Acción para agregar al pedido
        btnAgregar.addActionListener(e
                -> {
            String sabor = (String) comboSabor.getSelectedItem();
            String tamaño = (String) comboTamaño.getSelectedItem();
            int cantidad = (Integer) spnCantidad.getValue();
            double precio = obtenerPrecio(sabor, tamaño);

            lblPrecio.setText("Precio: $" + precio);
            if (sabor == null || tamaño == null || cantidad <= 0) {
                JOptionPane.showMessageDialog(this, "Por favor selecciona un sabor, tamaño y cantidad válidos.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int idHelado = obtenerCodigo(sabor, tamaño);

            if (precio <= 0 || idHelado <= 0) {
                JOptionPane.showMessageDialog(this, "Error al obtener datos del producto. Verifica la configuración.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                Conexion conexion = new Conexion();
                try (Connection conn = conexion.getConnection()) {
                    String sqlPedido = "INSERT INTO pedidos (id_cliente, fecha_pedido, fecha_entrega, total, estado, id_helado,codigoGrupo) VALUES (?, NOW(), ?, ?,?, ?, ?)";
                    try (PreparedStatement psPedido = conn.prepareStatement(sqlPedido)) {
                        int idCliente = Integer.parseInt(id);
                        String fechaEntrega = obtenerFechaActual();
                        String estado = "Pendiente";
                        double total = precio * cantidad;

                        psPedido.setInt(1, idCliente);
                        psPedido.setString(2, fechaEntrega);
                        psPedido.setDouble(3, total);
                        psPedido.setString(4, estado);
                        psPedido.setInt(5, idHelado);
                        psPedido.setString(6, codigoGrupo);

                        psPedido.executeUpdate();
                        modeloPedido.addElement(sabor + " (" + tamaño + ") x" + cantidad);
                        lblPrecio.setText("Precio: $" + total);
                        codi.add(codigoPedido(codigoGrupo));

                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al guardar el producto: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        );

        btnEliminar.addActionListener(e
                -> {
            int indexSeleccionado = listaPedido.getSelectedIndex();

            if (indexSeleccionado != -1) {
                modeloPedido.remove(indexSeleccionado);
                //eliminar de pedido
                eliminarPedido(Integer.parseInt(codi.get(indexSeleccionado)));
                codi.remove(indexSeleccionado);

            } else {
                JOptionPane.showMessageDialog(this, "Por favor, selecciona un producto para eliminar.", "Error", JOptionPane.WARNING_MESSAGE);
            }
        }
        );

        // Actualizar tamaños cuando se seleccione un sabor
        comboSabor.addActionListener(e
                -> actualizarTamanos());

        setVisible(
                true);
    }

    private void cargarSabores() {

        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            if (conn != null) {
                // Consulta SQL para obtener los sabores
                String sql = "SELECT DISTINCT nombre_sabor FROM helados";
                PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();

                // Limpiar el JComboBox antes de cargar nuevos datos
                comboSabor.removeAllItems();

                while (rs.next()) {
                    comboSabor.addItem(rs.getString("nombre_sabor"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar los sabores: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarTamanos() {
        String saborSeleccionado = (String) comboSabor.getSelectedItem();
        if (saborSeleccionado != null) {
            try {
                Conexion conexion = new Conexion();
                Connection conn = conexion.getConnection();

                if (conn != null) {
                    // Consulta SQL para obtener los tamaños disponibles para el sabor seleccionado
                    String sql = "SELECT DISTINCT nombre_tamaño FROM helados WHERE nombre_sabor = ?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setString(1, saborSeleccionado);
                    ResultSet rs = ps.executeQuery();

                    // Limpiar el JComboBox de tamaños antes de agregar nuevos datos
                    comboTamaño.removeAllItems();

                    while (rs.next()) {
                        comboTamaño.addItem(rs.getString("nombre_tamaño"));
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al cargar los tamaños: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private double obtenerPrecio(String sabor, String tamaño) {

        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "SELECT precio FROM helados WHERE nombre_sabor = ? AND nombre_tamaño = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, sabor);
            ps.setString(2, tamaño);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("precio");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private int obtenerCodigo(String sabor, String tamaño) {

        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "SELECT id_helado FROM helados WHERE nombre_sabor = ? AND nombre_tamaño = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, sabor);
            ps.setString(2, tamaño);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("id_helado");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private void cancelarPedido(String codigoGrupos) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "DELETE FROM `pedidos` WHERE codigoGrupo = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, codigoGrupos);
            ps.executeUpdate();

        } catch (SQLException e) {
        }
    }

    private void eliminarPedido(int codigo) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "Delete FROM `pedidos` WHERE id_pedido=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, codigo);
            ps.executeUpdate();

        } catch (SQLException e) {
        }
    }

    private String codigoPedido(String codigoGrupo) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "SELECT id_pedido FROM pedidos WHERE codigoGrupo = ? ORDER BY id_pedido DESC LIMIT 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, codigoGrupo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("id_pedido");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    String obtenerFechaActual() {
        LocalDate fechaActual = LocalDate.now();

        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        return fechaActual.format(formato);
    }

    //genera un codigo al azar para poder asociar con cada pedido
    public static String generarCodigo() {
        String prefijo = "Ped";
        Random random = new Random();
        int numero = 1000 + random.nextInt(9000);
        return prefijo + numero;
    }

    public static void main(String[] args) {
        new HeladeriaApp();
    }
}
