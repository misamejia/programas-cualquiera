package Vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Registrarse extends JFrame {

    private final JTextField txtUsuario;
    private final JPasswordField txtContrasena;
    private final JTextField txtNombreCompleto;
    private final JTextField txtEmail;
    private final JComboBox<String> comboTipoUsuario;

    public Registrarse() {
        setTitle("Registro de Usuario");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(7, 2)); // Cambiado a 7 filas para incluir el ComboBox

        JLabel lblUsuario = new JLabel("Nombre de usuario:");
        txtUsuario = new JTextField();

        JLabel lblContrasena = new JLabel("Contraseña:");
        txtContrasena = new JPasswordField();

        JLabel lblNombreCompleto = new JLabel("Nombre completo:");
        txtNombreCompleto = new JTextField();

        JLabel lblEmail = new JLabel("Correo electrónico:");
        txtEmail = new JTextField();

        JLabel lblTipoUsuario = new JLabel("Tipo de usuario:");
        comboTipoUsuario = new JComboBox<>(new String[]{"Empleado", "Cliente", "Administrador", "Distribuidor"});

        JButton btnRegistrarse = new JButton("Registrarse");
        JButton btnCancelar = new JButton("Cancelar");

        add(lblUsuario);
        add(txtUsuario);
        add(lblContrasena);
        add(txtContrasena);
        add(lblNombreCompleto);
        add(txtNombreCompleto);
        add(lblEmail);
        add(txtEmail);
        add(lblTipoUsuario); // Añadido JLabel para el ComboBox
        add(comboTipoUsuario); // Añadido ComboBox
        add(btnRegistrarse);
        add(btnCancelar);

        btnRegistrarse.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarUsuario();
            }
        });

        btnCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    private void registrarUsuario() {
        String usuario = txtUsuario.getText();
        String contrasena = new String(txtContrasena.getPassword());
        String nombreCompleto = txtNombreCompleto.getText();
        String email = txtEmail.getText();
        String tipoUsuario = comboTipoUsuario.getSelectedItem().toString(); // Obtener tipo de usuario seleccionado

        if (usuario.isEmpty() || contrasena.isEmpty() || nombreCompleto.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, completa todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3308/heladeria", "root", "");
            String sql = "INSERT INTO usuarios (nombre_usuario, contrasena_usuario, nombre_completo, email, tipo_usuario) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conexion.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, contrasena);
            ps.setString(3, nombreCompleto);
            ps.setString(4, email);
            ps.setString(5, tipoUsuario); // Incluir tipo de usuario en la inserción

            int resultado = ps.executeUpdate();

            if (resultado > 0) {
                JOptionPane.showMessageDialog(this, "Registro exitoso.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al registrar el usuario.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            ps.close();
            conexion.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al conectarse a la base de datos: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new Registrarse();
    }
}
