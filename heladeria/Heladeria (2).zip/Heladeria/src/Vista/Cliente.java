package Vista;

import javax.swing.*;
import java.awt.*;

public class Cliente extends JFrame {

    public Cliente() {
        initComponents();
        this.setTitle("Panel de Cliente");
        this.setSize(600, 400);
        this.setLocationRelativeTo(null); // Centrar en la pantalla
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void initComponents() {
        // Crear componentes
        JLabel lblWelcome = new JLabel("Bienvenido, Cliente");
        lblWelcome.setFont(new Font("Arial", Font.BOLD, 24));
        
        JButton btnViewProducts = new JButton("Ver Productos");
        JButton btnViewOrders = new JButton("Ver Mis Pedidos");
        JButton btnProfile = new JButton("Ver Perfil");
        JButton btnLogout = new JButton("Cerrar Sesión");

        // Agregar acciones a los botones
        btnViewProducts.addActionListener(evt -> viewProducts());
        btnViewOrders.addActionListener(evt -> viewOrders());
        btnProfile.addActionListener(evt -> viewProfile());
        btnLogout.addActionListener(evt -> logout());

        // Crear un panel y agregar componentes
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1, 10, 10)); // 5 filas, 1 columna
        panel.add(lblWelcome);
        panel.add(btnViewProducts);
        panel.add(btnViewOrders);
        panel.add(btnProfile);
        panel.add(btnLogout);

        // Agregar el panel a la ventana
        this.getContentPane().add(panel);
    }

    private void viewProducts() {
        // Lógica para ver productos
        JOptionPane.showMessageDialog(this, "Funcionalidad para ver productos.");
    }

    private void viewOrders() {
        // Lógica para ver pedidos
        JOptionPane.showMessageDialog(this, "Funcionalidad para ver mis pedidos.");
    }

    private void viewProfile() {
        // Lógica para ver perfil del cliente
        JOptionPane.showMessageDialog(this, "Funcionalidad para ver perfil.");
    }

    private void logout() {
        // Lógica para cerrar sesión y volver a la pantalla de login
        new Login().setVisible(true);
        this.dispose(); // Cerrar la ventana de cliente
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            new Cliente().setVisible(true);
        });
    }
}
