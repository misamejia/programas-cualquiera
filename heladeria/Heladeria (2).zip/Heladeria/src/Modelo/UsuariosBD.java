/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Conector.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import  Modelo.Usuario;

/**
 *
 * @author WINDOWS 10
 */
public class UsuariosBD {

    public void CargarTipoDeUsuarios(JComboBox comboBox) {
        try {
            String query;
            PreparedStatement ps;
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            query = "SELECT DISTINCT `tipo_usuario` FROM `usuarios`";
            ps = conn.prepareStatement(query);

            ResultSet rs = ps.executeQuery();

            comboBox.removeAllItems();
            comboBox.addItem("Seleccione");

            comboBox.addItem("Todos");
            while (rs.next()) {
                comboBox.addItem(rs.getString("tipo_usuario"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar estados: " + e.getMessage());
        }
    }

    public void mostrarTodos(DefaultTableModel tabla) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String query = "SELECT id_usuario, nombre_usuario, contrasena_usuario, nombre_completo, email, fecha_registro, tipo_usuario FROM usuarios";

            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                tabla.addRow(new Object[]{
                    rs.getString("id_usuario"),
                    rs.getString("nombre_usuario"),
                    rs.getString("nombre_completo"),
                    rs.getString("email"),
                    rs.getString("tipo_usuario"),
                    rs.getString("contrasena_usuario")});
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void mostrarPorCedula(DefaultTableModel tabla, int idUsuario) {
        String query = "SELECT id_usuario, nombre_usuario, contrasena_usuario, nombre_completo, email, fecha_registro, tipo_usuario FROM usuarios WHERE id_usuario = ?";
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                tabla.addRow(new Object[]{
                    rs.getString("id_usuario"),
                    rs.getString("nombre_usuario"),
                    rs.getString("nombre_completo"),
                    rs.getString("email"),
                    rs.getString("tipo_usuario"),
                    rs.getString("contrasena_usuario")});
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void mostrarPorTipoUsuario(DefaultTableModel tabla, String tipoUsuario) {
        String query = "SELECT id_usuario, nombre_usuario, contrasena_usuario, nombre_completo, email, fecha_registro, tipo_usuario FROM usuarios WHERE tipo_usuario = ?";
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, tipoUsuario);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                tabla.addRow(new Object[]{
                    rs.getString("id_usuario"),
                    rs.getString("nombre_usuario"),
                    rs.getString("nombre_completo"),
                    rs.getString("email"),
                    rs.getString("tipo_usuario"),
                    rs.getString("contrasena_usuario")});
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }

    public void eliminarUsuarioPorId(int idUsuario) {

        String verificarTipo = "SELECT tipo_usuario FROM usuarios WHERE id_usuario = ?";
        String verificarPedidos = "SELECT estado FROM pedidos WHERE idRepartidor = ? AND estado = 'Aceptado'";
        String eliminarUsuario = "DELETE FROM usuarios WHERE id_usuario = ?";
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            PreparedStatement stmtVerificarTipo = conn.prepareStatement(verificarTipo);
            stmtVerificarTipo.setInt(1, idUsuario);
            ResultSet rsTipo = stmtVerificarTipo.executeQuery();

            if (rsTipo.next()) {
                String tipoUsuario = rsTipo.getString("tipo_usuario");

                // Si es distribuidor, verificar pedidos asociados
                if ("Distribuidor".equalsIgnoreCase(tipoUsuario)) {
                    PreparedStatement stmtVerificarPedidos = conn.prepareStatement(verificarPedidos);
                    stmtVerificarPedidos.setInt(1, idUsuario);
                    ResultSet rsPedidos = stmtVerificarPedidos.executeQuery();

                    if (rsPedidos.next()) {
                        JOptionPane.showMessageDialog(null, "No se puede eliminar el repartidor, tiene pedidos asociados con estado 'Aceptado'.");
                        return;
                    }
                }

                // Eliminar usuario
                PreparedStatement stmtEliminar = conn.prepareStatement(eliminarUsuario);
                stmtEliminar.setInt(1, idUsuario);
                int filasAfectadas = stmtEliminar.executeUpdate();

                if (filasAfectadas > 0) {
                    JOptionPane.showMessageDialog(null, "Usuario eliminado exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(null, "No se encontró un usuario con el ID proporcionado.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró un usuario con el ID proporcionado.");
            }

            conn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }


    public ArrayList<String[]> mostrarDatosPorId(int idUsuario) {
        String query = "SELECT id_usuario, nombre_usuario, contrasena_usuario, nombre_completo, email, fecha_registro, tipo_usuario FROM usuarios WHERE id_usuario = ?";
        ArrayList<String[]> resultado = new ArrayList<>();
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, idUsuario);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                resultado.add(new String[]{
                    rs.getString("id_usuario"),
                    rs.getString("nombre_usuario"),
                    rs.getString("nombre_completo"),
                    rs.getString("email"),
                    rs.getString("tipo_usuario"),
                    rs.getString("contrasena_usuario")
                });
            }
            conn.close();
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return resultado;
    }
    
    public boolean actualizarUsuario(int idUsuario, Usuario usuario) {
    String verificarNombre = "SELECT COUNT(*) AS total FROM usuarios WHERE nombre_completo = ? AND id_usuario != ?";
    String actualizar = "UPDATE usuarios SET nombre_usuario = ?, nombre_completo = ?, email = ?, tipo_usuario = ?, contrasena_usuario = ? WHERE id_usuario = ?";

    try {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();

        // Verificar si el nombre completo ya existe
        PreparedStatement stmtVerificar = conn.prepareStatement(verificarNombre);
        stmtVerificar.setString(1, usuario.getNombreCompleto());
        stmtVerificar.setInt(2, idUsuario);
        ResultSet rs = stmtVerificar.executeQuery();
        if (rs.next() && rs.getInt("total") > 0) {
            JOptionPane.showMessageDialog(null, "El nombre completo ya está registrado.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        // Actualizar usuario
        PreparedStatement stmtActualizar = conn.prepareStatement(actualizar);
        stmtActualizar.setString(1, usuario.getNombreUsuario());
        stmtActualizar.setString(2, usuario.getNombreCompleto());
        stmtActualizar.setString(3, usuario.getEmail());
        stmtActualizar.setString(4, usuario.getTipoUsuario());
        stmtActualizar.setString(5, usuario.getContrasena());
        stmtActualizar.setInt(6, idUsuario);

        int filasAfectadas = stmtActualizar.executeUpdate();
        if (filasAfectadas > 0) {
            JOptionPane.showMessageDialog(null, "Usuario actualizado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "No se pudo actualizar el usuario.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    return false;
}


}
