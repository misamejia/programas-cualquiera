package Modelo;

public class Helado {
    private final String sabor;
    private final String tamaño;
    private final double precio;
    private int cantidad;

    public Helado(String sabor, String tamaño, double precio) {
        this.sabor = sabor;
        this.tamaño = tamaño;
        this.precio = precio;
        this.cantidad = 0;
    }

    public String getSabor() {
        return sabor;
    }

    public String getTamaño() {
        return tamaño;
    }

    public double getPrecio() {
        return precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad += cantidad;
    }

    @Override
public String toString() {
    return String.format("%s (%s) - Cantidad: %d", sabor, tamaño, cantidad);
}

}