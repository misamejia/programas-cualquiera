/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Conector.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author WINDOWS 10
 */
public class InventarioBD {

    public void mostrarDatos(DefaultTableModel tabla, String busqueda) {
        try {
            String query;
            PreparedStatement ps;
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            if (busqueda != null && !busqueda.trim().isEmpty()) {
                query = "SELECT `id_helado`, `nombre_sabor`, `nombre_tamaño`, `precio` "
                        + "FROM `helados` "
                        + "WHERE `nombre_sabor` LIKE ? OR `nombre_tamaño` LIKE ?  OR `id_helado` LIKE ? ";
                ps = conn.prepareStatement(query);
                ps.setString(1, "%" + busqueda + "%");
                ps.setString(2, "%" + busqueda + "%");
                ps.setString(3, "%" + busqueda + "%");

            } else {
                query = "SELECT `id_helado`, `nombre_sabor`, `nombre_tamaño`, `precio` FROM `helados`";
                ps = conn.prepareStatement(query);
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                tabla.addRow(new Object[]{
                    rs.getString("id_helado"),
                    rs.getString("nombre_sabor"),
                    rs.getString("nombre_tamaño"),
                    rs.getString("precio"),});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar datos: " + e.getMessage());
        }
    }

}
