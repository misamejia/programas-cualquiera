package Modelo;

import java.util.List;

public class Factura {
    private final Pedido pedido;

    public Factura(Pedido pedido) {
        this.pedido = pedido;
    }

    public String imprimirFactura() {
        StringBuilder sb = new StringBuilder();
        sb.append("Factura:\n");
        List<Helado> helados = pedido.getHelados();

        if (helados.isEmpty()) {
            return "No hay helados en el pedido.";
        }

        double total = 0;
        for (Helado helado : helados) {
            double precioTotal = helado.getPrecio();
            total += precioTotal;
            sb.append(helado.getSabor())
              .append(" (").append(helado.getTamaño()).append(") - Precio: ").append(precioTotal).append("\n");
        }

        sb.append("Total a pagar: ").append(total).append("\n");
        return sb.toString();
    }
}
