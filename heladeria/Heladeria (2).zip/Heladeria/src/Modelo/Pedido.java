package Modelo;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
    public int idPedido;
    public int id_cliente;
    public String CodigoGrupo;
    public String fecha_pedido;
    public String fecha_entrega;
    public String estado;
    public int id_helado;
    public int cantidad;
    public float total;
    public String tamaño;

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }


    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public int getId_helado() {
        return id_helado;
    }

    public void setId_helado(int id_helado) {
        this.id_helado = id_helado;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }



    public String getCodigoGrupo() {
        return CodigoGrupo;
    }

    public void setCodigoGrupo(String CodigoGrupo) {
        this.CodigoGrupo = CodigoGrupo;
    }

    public String getFecha_pedido() {
        return fecha_pedido;
    }

    public void setFecha_pedido(String fecha_pedido) {
        this.fecha_pedido = fecha_pedido;
    }

    public String getFecha_entrega() {
        return fecha_entrega;
    }

    public void setFecha_entrega(String fecha_entrega) {
        this.fecha_entrega = fecha_entrega;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }



    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }
    
    private final List<Helado> helados;

    public Pedido() {
        helados = new ArrayList<>();
    }

    public void agregarHelado(Helado helado, int cantidad) {
        for (Helado h : helados) {
            if (h.getSabor().equals(helado.getSabor()) && h.getTamaño().equals(helado.getTamaño())) {
                h.setCantidad(cantidad);
                return;
            }
        }
        helado.setCantidad(cantidad);
        helados.add(helado);
    }

    public List<Helado> getHelados() {
        return helados;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Helado helado : helados) {
            sb.append(helado.toString()).append("\n");
        }
        return sb.toString();
    }
}