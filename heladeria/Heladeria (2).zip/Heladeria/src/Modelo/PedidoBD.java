/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Conector.Conexion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author WINDOWS 10
 */
public class PedidoBD {

    public void añadirPedido(Pedido pedi) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            // Verificar si ya existe un pedido con el mismo codigoGrupo, id_cliente, id_helado y tamaño
            String sqlVerificar = "SELECT cantidad FROM pedidos WHERE codigoGrupo = ? AND id_cliente = ? AND id_helado = ? AND tamaño = ?";
            PreparedStatement psVerificar = conn.prepareStatement(sqlVerificar);
            psVerificar.setString(1, pedi.getCodigoGrupo());
            psVerificar.setInt(2, pedi.getId_cliente());
            psVerificar.setInt(3, pedi.getId_helado());
            psVerificar.setString(4, pedi.getTamaño());

            ResultSet rs = psVerificar.executeQuery();

            if (rs.next()) {
                // Si existe un pedido con el mismo codigoGrupo, id_cliente, id_helado y tamaño, actualizar la cantidad
                int cantidadExistente = rs.getInt("cantidad");
                int nuevaCantidad = cantidadExistente + pedi.getCantidad();

                String sqlActualizar = "UPDATE pedidos SET cantidad = ? WHERE codigoGrupo = ? AND id_cliente = ? AND id_helado = ? AND tamaño = ?";
                PreparedStatement psActualizar = conn.prepareStatement(sqlActualizar);
                psActualizar.setInt(1, nuevaCantidad);
                psActualizar.setString(2, pedi.getCodigoGrupo());
                psActualizar.setInt(3, pedi.getId_cliente());
                psActualizar.setInt(4, pedi.getId_helado());
                psActualizar.setString(5, pedi.getTamaño());

                psActualizar.executeUpdate();
                JOptionPane.showMessageDialog(null, "Cantidad actualizada en el pedido existente");

            } else {
                // Si no existe un pedido con ese codigoGrupo, id_cliente, id_helado y tamaño, insertar el nuevo pedido
                String sqlPedido = "INSERT INTO pedidos (id_cliente, fecha_pedido, total, estado, id_helado, codigoGrupo, cantidad, tamaño) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement psPedido = conn.prepareStatement(sqlPedido);
                int idCliente = pedi.getId_cliente();
                String fechaEntrega = obtenerFechaActual();
                String estado = "En carrito";
                double precio = obtenerPrecio(pedi.getId_helado());
                double total = pedi.getCantidad() * precio;
                psPedido.setInt(1, idCliente);
                psPedido.setString(2, fechaEntrega);
                psPedido.setDouble(3, total);
                psPedido.setString(4, estado);
                psPedido.setInt(5, pedi.getId_helado());
                psPedido.setString(6, pedi.getCodigoGrupo());
                psPedido.setInt(7, pedi.getCantidad());
                psPedido.setString(8, pedi.getTamaño());

                psPedido.executeUpdate();
                JOptionPane.showMessageDialog(null, "Producto añadido");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al guardar el producto: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void cargarSabores(JComboBox comboSabor) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            if (conn != null) {
                String sql = "SELECT DISTINCT nombre_sabor FROM helados";
                PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                comboSabor.removeAllItems();
                comboSabor.addItem("Seleccione");
                while (rs.next()) {
                    comboSabor.addItem(rs.getString("nombre_sabor"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los sabores: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void actualizarTamanos(JComboBox comboSabor, JComboBox comboTamaño) {

        String saborSeleccionado = (String) comboSabor.getSelectedItem();

        if (saborSeleccionado != null) {
            try {
                Conexion conexion = new Conexion();
                Connection conn = conexion.getConnection();

                if (conn != null) {
                    String sql = "SELECT DISTINCT nombre_tamaño FROM helados WHERE nombre_sabor = ?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setString(1, saborSeleccionado);
                    ResultSet rs = ps.executeQuery();
                    comboTamaño.removeAllItems();
                    comboSabor.addItem("Seleccione");

                    while (rs.next()) {
                        comboTamaño.addItem(rs.getString("nombre_tamaño"));
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al cargar los tamaños: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public double obtenerPrecio(int idHelado) {

        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "SELECT precio FROM helados WHERE id_helado = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idHelado);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("precio");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int obtenerCodigoDelHelado(String sabor, String tamaño) {

        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "SELECT id_helado FROM helados WHERE nombre_sabor = ? AND nombre_tamaño = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, sabor);
            ps.setString(2, tamaño);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("id_helado");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int obtenerCodigoDelPedido(int id_helado, String codigogrupo) {

        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "SELECT id_pedido FROM pedidos WHERE id_helado=? And codigoGrupo=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id_helado);
            ps.setString(2, codigogrupo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("id_pedido");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public void cancelarPedido(String codigoGrupos) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "DELETE FROM `pedidos` WHERE codigoGrupo = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, codigoGrupos);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Pedido cancelado..");

        } catch (SQLException e) {
        }
    }

    public void eliminarPedido(int codigo) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "Delete FROM `pedidos` WHERE id_pedido=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, codigo);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Pedido eliminado");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al eliminar el pedido: " + e.getMessage());
        }

    }

    public String codigoPedido(String codigoGrupo) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "SELECT id_pedido FROM pedidos WHERE codigoGrupo = ? ORDER BY id_pedido DESC LIMIT 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, codigoGrupo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("id_pedido");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    String obtenerFechaActual() {
        LocalDate fechaActual = LocalDate.now();

        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        return fechaActual.format(formato);
    }

    //genera un codigo al azar para poder asociar con cada pedido
    public String generarCodigo() {
        String prefijo = "Ped";
        Random random = new Random();
        int numero = 1000 + random.nextInt(9000);
        return prefijo + numero;
    }

    public String GenerarCodigo(String id, String estado) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sqlPedido = "SELECT codigoGrupo FROM pedidos WHERE estado = ? AND id_cliente = ? ORDER BY id_pedido DESC LIMIT 1";
            PreparedStatement psPedido = conn.prepareStatement(sqlPedido);
            psPedido.setInt(2, Integer.parseInt(id));
            psPedido.setString(1, estado);
            ResultSet rsPedido = psPedido.executeQuery();
            if (rsPedido.next()) {
                return rsPedido.getString("codigoGrupo");
            } else {
                return generarCodigo();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void PedidosAñadidos(DefaultTableModel tabla, Integer idCliente, Integer idRepartidor, String codigog, String estado) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            String sql;
            if (idCliente != null) {
                sql = "SELECT p.total, p.tamaño, "
                        + "(SELECT helados.nombre_sabor FROM helados WHERE helados.id_helado = p.id_helado) AS nombre_helado, "
                        + "p.cantidad, e.codigoGrupo, e.fecha_envio, e.metodo_envio, e.costo_envio "
                        + "FROM pedidos p "
                        + "LEFT JOIN envios e ON p.codigoGrupo = e.codigoGrupo "
                        + "WHERE p.estado = ? AND p.id_cliente = ? AND p.codigoGrupo = ?";
            } else if (idRepartidor != null) {
                sql = "SELECT p.total, p.tamaño, "
                        + "(SELECT helados.nombre_sabor FROM helados WHERE helados.id_helado = p.id_helado) AS nombre_helado, "
                        + "p.cantidad, e.codigoGrupo, e.fecha_envio, e.metodo_envio, e.costo_envio "
                        + "FROM pedidos p "
                        + "LEFT JOIN envios e ON p.codigoGrupo = e.codigoGrupo "
                        + "WHERE p.estado = ? AND p.idRepartidor = ? AND p.codigoGrupo = ?";
            } else {
                JOptionPane.showMessageDialog(null, "Debe pasar al menos un ID (Cliente o Repartidor).");
                return;
            }

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, estado);
            ps.setString(3, codigog);
            if (idCliente != null) {
                ps.setInt(2, idCliente);
            } else {
                ps.setInt(2, idRepartidor);
            }

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String nombreHelado = rs.getString("nombre_helado");
                String tamaño = rs.getString("p.tamaño");
                String cantidad = rs.getString("p.cantidad");
                String total = rs.getString("p.total");
                String fechaEnvio = rs.getString("e.fecha_envio");
                if (fechaEnvio == null) {
                    fechaEnvio = "En espera";
                }
                String metodoEnvio = rs.getString("e.metodo_envio");
                if (metodoEnvio == null) {
                    metodoEnvio = "No disponible";
                }
                String costoEnvio = rs.getString("e.costo_envio");
                if (costoEnvio == null) {
                    costoEnvio = "No disponible";
                }

                tabla.addRow(new Object[]{
                    nombreHelado,
                    tamaño,
                    cantidad,
                    total,
                    fechaEnvio,
                    metodoEnvio,
                    costoEnvio
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al mostrar los datos: " + e);
        }
    }

    public String idUltimoPedido() {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sqlPedido = "SELECT codigoGrupo FROM pedidos WHERE estado = 'Pendiente' ORDER BY id_pedido DESC LIMIT 1";
            PreparedStatement psPedido = conn.prepareStatement(sqlPedido);
            ResultSet rsPedido = psPedido.executeQuery();
            if (rsPedido.next()) {
                return rsPedido.getString("codigoGrupo");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String CodigoPedidoRepartidorAsociado(String cedula) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sqlPedido = "SELECT codigoGrupo FROM pedidos WHERE estado = 'Aceptado' AND idRepartidor = ? ORDER BY id_pedido DESC LIMIT 1";
            PreparedStatement psPedido = conn.prepareStatement(sqlPedido);
            psPedido.setString(1, cedula);
            ResultSet rsPedido = psPedido.executeQuery();
            if (rsPedido.next()) {
                return rsPedido.getString("codigoGrupo");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String pedidosPendientes() {
        try (Connection conn = new Conexion().getConnection()) {
            String codigoGrupo = idUltimoPedido(conn);
            if (codigoGrupo == null) {
                return "No hay pedidos pendientes.";
            }

            PedidoInfo pedidoInfo = obtenerInfoPedido(conn, codigoGrupo, "Pendiente");
            if (pedidoInfo == null) {
                return "No se encontraron detalles para el último pedido.";
            }

            String nombreUsuario = obtenerNombreCliente(conn, pedidoInfo.idCliente);
            String listaHelados = obtenerListaHelados(conn, codigoGrupo);
            double total = calcularTotalGrupo(conn, codigoGrupo);

            return "Último Pedido:\n"
                    + "Código del Pedido: " + pedidoInfo.idPedido + "\n"
                    + "Cliente: " + nombreUsuario + "\n"
                    + "Artículos:\n" + listaHelados
                    + "Total: $" + total;
        } catch (SQLException e) {
            e.printStackTrace();
            return "Ocurrió un error al obtener el pedido.";
        }
    }

    private String idUltimoPedido(Connection conn) throws SQLException {
        String sql = "SELECT codigoGrupo FROM pedidos WHERE estado = 'Pendiente' ORDER BY fecha_pedido DESC LIMIT 1";
        try (PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getString("codigoGrupo") : null;
        }
    }

    private PedidoInfo obtenerInfoPedido(Connection conn, String codigoGrupo, String estado) throws SQLException {
        String sql = "SELECT id_pedido, id_cliente FROM pedidos WHERE codigoGrupo = ? AND estado = ? LIMIT 1";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, codigoGrupo);
            ps.setString(2, estado);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? new PedidoInfo(rs.getInt("id_pedido"), rs.getInt("id_cliente")) : null;
            }
        }
    }

    private String obtenerNombreCliente(Connection conn, int idCliente) throws SQLException {
        String sql = "SELECT nombre_completo FROM usuarios WHERE id_usuario = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString("nombre_completo") : "Desconocido";
            }
        }
    }

    private String obtenerListaHelados(Connection conn, String codigoGrupo) throws SQLException {
        String sql = "SELECT h.nombre_sabor, p.cantidad "
                + "FROM helados h "
                + "JOIN pedidos p ON h.id_helado = p.id_helado "
                + "WHERE p.codigoGrupo = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, codigoGrupo);
            try (ResultSet rs = ps.executeQuery()) {
                StringBuilder listaHelados = new StringBuilder();
                int contador = 1;
                while (rs.next()) {
                    listaHelados.append(contador)
                            .append(") ")
                            .append(rs.getString("nombre_sabor"))
                            .append(" (Cantidad: ")
                            .append(rs.getInt("cantidad"))
                            .append(")\n");
                    contador++;
                }
                return listaHelados.toString();
            }
        }
    }

    private double calcularTotalGrupo(Connection conn, String codigoGrupo) throws SQLException {
        String sql = "SELECT SUM(total) AS total_grupo FROM pedidos WHERE codigoGrupo = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, codigoGrupo);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getDouble("total_grupo") : 0.0;
            }
        }
    }

    public void actualizarRepartidor(String idPedido, int idRepartidor) {
        try (Connection conn = new Conexion().getConnection()) {
            String sql = "UPDATE pedidos SET idRepartidor = ? WHERE codigoGrupo = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idRepartidor);
                ps.setString(2, idPedido);
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int obtenerIdUsuarioPorNombre(String nombreCompleto) {
        int idUsuario = -1;
        try (Connection conn = new Conexion().getConnection()) {
            String sql = "SELECT id_usuario FROM usuarios WHERE nombre_completo = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, nombreCompleto);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        idUsuario = rs.getInt("id_usuario");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return idUsuario;
    }

    public String ContarPedidos() {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "SELECT count(id_pedido) as numero FROM pedidos WHERE estado='Pendiente'";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("numero");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void ejecutarActualizacionEstado(String codigoGrupo, String nuevoEstado) {
        Conexion conexion = new Conexion();
        Connection conn = conexion.getConnection();
        String sql = "UPDATE pedidos SET estado = ?  WHERE codigoGrupo = ?";
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, nuevoEstado);
            ps.setString(2, codigoGrupo);
            if (ps.executeUpdate() > 0) {
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al intetar Cambiar estado del producto");

        }
    }

    public void EstadosPedidoPorID(JComboBox combo, int id) {

        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            if (conn != null) {
                String sql = "SELECT DISTINCT estado FROM pedidos where id_cliente=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                combo.removeAllItems();
                combo.addItem("Seleccione");
                while (rs.next()) {
                    combo.addItem(rs.getString("estado"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los estados: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void AñadirRepartidor(JComboBox combo) {

        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            if (conn != null) {
                String sql = "SELECT DISTINCT nombre_completo FROM usuarios where tipo_usuario='Distribuidor'";
                PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                combo.removeAllItems();
                combo.addItem("Seleccione");
                while (rs.next()) {
                    combo.addItem(rs.getString("nombre_completo"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los nombre_completo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    //Pedios 
    public String ContarPedidosAsiganados(int cedula) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sql = "SELECT count(id_pedido) as numero FROM pedidos WHERE estado='Aceptado' And idRepartidor=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, cedula);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("numero");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String pedidosAceptados(int idRepartidor) {
        try (Connection conn = new Conexion().getConnection()) {
            String codigoGrupo = idUltimoPedidoAceptado(conn, idRepartidor);
            if (codigoGrupo == null) {
                return "No hay pedidos aceptados para este repartidor.";
            }

            PedidoInfo pedidoInfo = obtenerInfoPedido(conn, codigoGrupo, "Aceptado");
            if (pedidoInfo == null) {
                return "No se encontraron detalles para el último pedido aceptado.";
            }

            String nombreUsuario = obtenerNombreCliente(conn, pedidoInfo.idCliente);
            String listaHelados = obtenerListaHelados(conn, codigoGrupo);
            double total = calcularTotalGrupo(conn, codigoGrupo);

            return "Último Pedido Aceptado:\n"
                    + "Código del Pedido: " + pedidoInfo.idPedido + "\n"
                    + "Cliente: " + nombreUsuario + "\n"
                    + "Artículos:\n" + listaHelados
                    + "Total: $" + total;
        } catch (SQLException e) {
            e.printStackTrace();
            return "Ocurrió un error al obtener el pedido aceptado.";
        }
    }

    public void EstadoRepartidor(JComboBox combo, int id) {

        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            if (conn != null) {
                String sql = "SELECT DISTINCT estado FROM pedidos where idRepartidor=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                combo.removeAllItems();
                combo.addItem("Seleccione");
                while (rs.next()) {
                    combo.addItem(rs.getString("estado"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los estados: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String idUltimoPedidoAceptado(Connection conn, int idRepartidor) throws SQLException {
        String sql = "SELECT codigoGrupo FROM pedidos WHERE estado='Aceptado' And idRepartidor=? ORDER BY fecha_pedido DESC LIMIT 1";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idRepartidor);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString("codigoGrupo") : null;
            }
        }
    }

    public boolean insertarEnvio(String metodoEnvio, double costoEnvio, String codigoGrupo) {
        String sql = "INSERT INTO envios (fecha_envio, metodo_envio, costo_envio, codigoGrupo) VALUES (?, ?, ?, ?)";
        try {
            Connection conn = new Conexion().getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            LocalDate fechaEnvio = LocalDate.now().plusDays(5);
            ps.setDate(1, java.sql.Date.valueOf(fechaEnvio));
            ps.setString(2, metodoEnvio);
            ps.setDouble(3, costoEnvio);
            ps.setString(4, codigoGrupo);
            int filasInsertadas = ps.executeUpdate();
            return filasInsertadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String CodigoRepartido(String id, String estado) {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            String sqlPedido = "SELECT codigoGrupo FROM pedidos WHERE estado = ? AND idRepartidor = ? ORDER BY id_pedido DESC LIMIT 1";
            PreparedStatement psPedido = conn.prepareStatement(sqlPedido);
            psPedido.setInt(2, Integer.parseInt(id));
            psPedido.setString(1, estado);
            ResultSet rsPedido = psPedido.executeQuery();
            if (rsPedido.next()) {
                return rsPedido.getString("codigoGrupo");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public double obtenerSumaTotal(int idCliente, String codigoGrupo) {
        double sumaTotal = 0.0;
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            // Consulta SQL para obtener la suma de los totales de los pedidos en estado "En carrito"
            String sql = "SELECT SUM(total) AS suma_total FROM pedidos WHERE id_cliente = ? AND codigoGrupo = ? AND estado = 'En carrito'";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idCliente);
            ps.setString(2, codigoGrupo);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                sumaTotal = rs.getDouble("suma_total");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener la suma del total: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return sumaTotal;
    }

    private class PedidoInfo {

        int idPedido;
        int idCliente;

        PedidoInfo(int idPedido, int idCliente) {
            this.idPedido = idPedido;
            this.idCliente = idCliente;
        }
    }

}
