-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3308
-- Tiempo de generación: 18-11-2024 a las 20:59:37
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `heladeria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nombre_cliente` varchar(150) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tipo_cliente` enum('Mayorista','Minorista') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nombre_cliente`, `direccion`, `telefono`, `email`, `tipo_cliente`) VALUES
(1, 'Supermercado Los Frescos', 'Avenida Principal 100, Ciudad A', '111222333', 'compras@losfrescos.com', 'Mayorista'),
(2, 'MiniMarket Central', 'Calle Secundaria 56, Ciudad B', '222333444', 'info@minimarketcentral.com', 'Minorista'),
(3, 'Tiendas El Helado', 'Carrera 10, Ciudad C', '333444555', 'pedidos@elhelado.com', 'Mayorista'),
(4, 'Kiosko Las Delicias', 'Plaza 45, Ciudad D', '444555666', 'ventas@kioskolasdelicias.com', 'Minorista'),
(5, 'Cafeter?a Dulce Vida', 'Avenida Las Flores 789, Ciudad E', '555666777', 'dulcevida@cafeteria.com', 'Minorista');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `envios`
--

CREATE TABLE `envios` (
  `id_envio` int(11) NOT NULL,
  `id_pedido` int(11) DEFAULT NULL,
  `fecha_envio` date NOT NULL,
  `metodo_envio` varchar(100) DEFAULT NULL,
  `costo_envio` decimal(7,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `envios`
--

INSERT INTO `envios` (`id_envio`, `id_pedido`, `fecha_envio`, `metodo_envio`, `costo_envio`) VALUES
(1, 1, '2024-10-03', 'Transporte Refrigerado', 25.00),
(2, 2, '2024-10-04', 'Entrega Express', 15.00),
(3, 3, '2024-10-06', 'Transporte Refrigerado', 30.00),
(4, 4, '2024-10-05', 'Mensajer?a', 10.00),
(5, 5, '2024-10-07', 'Transporte Refrigerado', 20.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `helados`
--

CREATE TABLE `helados` (
  `id_helado` int(11) NOT NULL,
  `nombre_sabor` varchar(50) DEFAULT NULL,
  `nombre_tamaño` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `helados`
--

INSERT INTO `helados` (`id_helado`, `nombre_sabor`, `nombre_tamaño`, `precio`) VALUES
(1, 'Vainilla', 'Pequeño', 10000.00),
(2, 'Vainilla', 'Mediano', 15000.00),
(3, 'Vainilla', 'Grande', 20000.00),
(4, 'Chocolate', 'Pequeño', 12000.00),
(5, 'Chocolate', 'Mediano', 17000.00),
(6, 'Chocolate', 'Grande', 22000.00),
(7, 'Helado de Vainilla', 'Grande', 5000.00),
(8, 'Helado de Vainilla', 'Mediano', 4000.00),
(9, 'Helado de Vainilla', 'Pequeño', 3000.00),
(10, 'Paleta de Fresa', 'Unico', 3000.00),
(11, 'Postre Helado de Oreo', 'Unico', 4000.00),
(12, 'Helado de Menta', 'Grande', 3000.00),
(13, 'Helado de Menta', 'Mediano', 2500.00),
(14, 'Helado de Menta', 'Pequeño', 2000.00),
(15, 'Helado de Mandarina', 'Grande', 1000.00),
(16, 'Helado de Mandarina', 'Mediano', 800.00),
(17, 'Helado de Mandarina', 'Pequeño', 600.00),
(18, 'helado de mango', 'mediano', 1200.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `id_inventario` int(11) NOT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_ingreso` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`id_inventario`, `id_producto`, `id_proveedor`, `cantidad`, `fecha_ingreso`) VALUES
(1, 1, 1, 200, '2024-09-20'),
(2, 2, 2, 150, '2024-09-22'),
(3, 3, 3, 300, '2024-09-25'),
(4, 4, 4, 100, '2024-09-28'),
(5, 5, 5, 180, '2024-09-30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `fecha_pedido` date NOT NULL,
  `fecha_entrega` date DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `estado` enum('Pendiente','Entregado','Cancelado') DEFAULT 'Pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id_pedido`, `id_cliente`, `fecha_pedido`, `fecha_entrega`, `total`, `estado`) VALUES
(1, 1, '2024-10-01', '2024-10-05', 300.00, 'Entregado'),
(2, 2, '2024-10-02', '2024-10-06', 150.00, 'Entregado'),
(3, 3, '2024-10-03', '2024-10-07', 500.00, 'Pendiente'),
(4, 4, '2024-10-04', '2024-10-08', 75.00, 'Entregado'),
(5, 5, '2024-10-05', '2024-10-09', 200.00, 'Pendiente'),
(6, 1, '2024-10-01', '2024-10-05', 300.00, 'Entregado'),
(7, 2, '2024-10-02', '2024-10-06', 150.00, 'Entregado'),
(8, 3, '2024-10-03', '2024-10-07', 500.00, 'Pendiente'),
(9, 4, '2024-10-04', '2024-10-08', 75.00, 'Entregado'),
(10, 5, '2024-10-05', '2024-10-09', 200.00, 'Pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL,
  `nombre_producto` varchar(100) NOT NULL,
  `tipo_producto` enum('Helado','Paleta','Postre Helado') NOT NULL,
  `precio_producto` decimal(7,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `tamaño` enum('Peque?o','Mediano','Grande') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `nombre_producto`, `tipo_producto`, `precio_producto`, `stock`, `tamaño`) VALUES
(1, 'Helado de Vainilla', 'Helado', 5000.00, 120, 'Grande'),
(2, 'Helado de Chocolate', 'Helado', 3000.00, 80, 'Peque?o'),
(3, 'Paleta de Fresa', 'Paleta', 3000.00, 150, 'Peque?o'),
(4, 'Postre Helado de Oreo', 'Postre Helado', 4000.00, 50, 'Mediano'),
(5, 'Helado de Menta', 'Helado', 3000.00, 120, 'Peque?o'),
(7, 'kiwi', 'Helado', 1000.00, 100, 'Peque?o'),
(8, 'helado de mandarina', 'Helado', 1000.00, 120, 'Peque?o');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id_proveedor` int(11) NOT NULL,
  `nombre_proveedor` varchar(150) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id_proveedor`, `nombre_proveedor`, `direccion`, `telefono`, `email`) VALUES
(1, 'Distribuidora Fr?a', 'Calle 123, Ciudad A', '123456789', 'contacto@distribuidorafria.com'),
(2, 'Helados del Norte', 'Avenida 45, Ciudad B', '987654321', 'info@heladosnorte.com'),
(3, 'Sabor y Salud', 'Carrera 67, Ciudad C', '456789123', 'ventas@saborysalud.com'),
(4, 'Sabores Exquisitos', 'Calle 89, Ciudad D', '321654987', 'soporte@saboresexquisitos.com'),
(5, 'Frozen Delights', 'Avenida 12, Ciudad E', '654987321', 'contacto@frozendelights.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `contrasena_usuario` varchar(255) NOT NULL,
  `nombre_completo` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  `tipo_usuario` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre_usuario`, `contrasena_usuario`, `nombre_completo`, `email`, `fecha_registro`, `tipo_usuario`) VALUES
(1, 'admin', '1234', 'admin2', 'admin@ejemplo.com', '2024-10-15 16:53:33', 'Administrador'),
(2, 'jose', '1234', 'Jose Pérez', 'jose@ejemplo.com', '2024-10-15 16:53:33', 'Cliente'),
(6, 'misa', '1234', 'misael', 'misaelmejia427', '2024-10-15 19:09:04', 'administrador'),
(8, 'Wilmer', '1234', 'Wilmer Sierra', 'wilmersierra123@gmail.com', '2024-10-17 17:10:26', 'Empleado'),
(12, 'daniel', '1234', 'daniel 2', 'kamdoanosdna', '2024-10-17 23:50:41', 'Distribuidor');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Indices de la tabla `envios`
--
ALTER TABLE `envios`
  ADD PRIMARY KEY (`id_envio`),
  ADD KEY `id_pedido` (`id_pedido`);

--
-- Indices de la tabla `helados`
--
ALTER TABLE `helados`
  ADD PRIMARY KEY (`id_helado`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`id_inventario`),
  ADD KEY `id_producto` (`id_producto`),
  ADD KEY `id_proveedor` (`id_proveedor`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id_proveedor`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `nombre_usuario` (`nombre_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `envios`
--
ALTER TABLE `envios`
  MODIFY `id_envio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `helados`
--
ALTER TABLE `helados`
  MODIFY `id_helado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `id_inventario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id_proveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `envios`
--
ALTER TABLE `envios`
  ADD CONSTRAINT `envios_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`);

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`),
  ADD CONSTRAINT `inventario_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`);

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
