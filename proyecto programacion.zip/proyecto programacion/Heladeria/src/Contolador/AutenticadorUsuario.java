/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Contolador;

import Conector.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author EQUIPO
 */

public class AutenticadorUsuario {
    private Conexion conexion;

    public AutenticadorUsuario() {
        conexion = new Conexion();
    }

    public Integer autenticarUsuario(String email, String contraseña, String tipoUsuario) {
        String sql = "SELECT id FROM USUARIO WHERE email = ? AND contraseña = ? AND tipo_usuario = ?";
        try (Connection conn = conexion.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, contraseña);
            ps.setString(3, tipoUsuario);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("id"); // Devuelve el ID del usuario autenticado
            } else {
                return null; // No se encontró el usuario
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
