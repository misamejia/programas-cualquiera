/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

public class Inventario {
    private int id;
    private String sabor;
    private String tamaño;
    private int cantidad;

    public Inventario(int id, String sabor, String tamaño, int cantidad) {
        this.id = id;
        this.sabor = sabor;
        this.tamaño = tamaño;
        this.cantidad = cantidad;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSabor() {
        return sabor;
    }

    public void setSabor(String sabor) {
        this.sabor = sabor;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "Inventario{" +
                "id=" + id +
                ", sabor='" + sabor + '\'' +
                ", tamaño='" + tamaño + '\'' +
                ", cantidad=" + cantidad +
                '}';
    }
}

