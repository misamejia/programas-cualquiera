package Modelo;

import java.util.ArrayList;
import java.util.List;

public class Pedido {
    private final List<Helado> helados;

    public Pedido() {
        helados = new ArrayList<>();
    }

    public void agregarHelado(Helado helado, int cantidad) {
        for (Helado h : helados) {
            if (h.getSabor().equals(helado.getSabor()) && h.getTamaño().equals(helado.getTamaño())) {
                h.setCantidad(cantidad);
                return;
            }
        }
        helado.setCantidad(cantidad);
        helados.add(helado);
    }

    public List<Helado> getHelados() {
        return helados;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Helado helado : helados) {
            sb.append(helado.toString()).append("\n");
        }
        return sb.toString();
    }
}