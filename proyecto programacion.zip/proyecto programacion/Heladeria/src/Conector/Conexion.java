package Conector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexion {
    private Connection connection;

    public Conexion() {
        conectar();
    }

    private void conectar() {
        try {
            String url = "jdbc:mysql://localhost:3308/heladeria";
            String user = "root";
            String password = "";
            
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Conexión exitosa a la base de datos.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e.getMessage(), "Error de Conexión", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean validarUsuario(String usuario, String contrasena, String tipoUsuario) {
        String sql = "SELECT * FROM usuarios WHERE nombre_usuario = ? AND contrasena_usuario = ? AND tipo_usuario = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, contrasena);
            ps.setString(3, tipoUsuario);
        
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al validar el usuario: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
}

    public Connection getConnection() {
        return connection;
    }

    public boolean isConnectionOpen() {
        return connection != null;
    }
}