package Vista;

import Conector.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;
import java.awt.*;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class HeladeriaApp extends JFrame {
    private JComboBox<String> comboSabor;
    private JComboBox<String> comboTamaño;
    private JLabel lblPrecio;
    private JSpinner spnCantidad;
    private JButton btnAgregar;
    private JButton btnEliminar;
    private JList<String> listaPedido;
    private DefaultListModel<String> modeloPedido;

    public HeladeriaApp() {
        setTitle("Heladería");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 600);
        setLocationRelativeTo(null);  // Centra la ventana en la pantalla

        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(9, 1, 10, 10));  // Aumentado el número de filas para incluir el nuevo botón
        add(panel);

        // Logo de la heladería
        JLabel lblLogo = new JLabel(new ImageIcon(getClass().getResource("/icon/logo.png")));
        panel.add(lblLogo);

        // Nombre de la heladería
        JLabel lblNombre = new JLabel("Heladería ICE DREAM", SwingConstants.CENTER);
        lblNombre.setFont(new Font("Arial", Font.BOLD, 24));
        panel.add(lblNombre);

        // Selección de sabor
        JLabel lblSabor = new JLabel("Selecciona el sabor:");
        comboSabor = new JComboBox<>();
        panel.add(lblSabor);
        panel.add(comboSabor);

        // Selección de tamaño
        JLabel lblTamaño = new JLabel("Selecciona el tamaño:");
        comboTamaño = new JComboBox<>();
        panel.add(lblTamaño);
        panel.add(comboTamaño);

        // Mostrar el precio
        lblPrecio = new JLabel("Precio: $0.00");
        panel.add(lblPrecio);

        // Selección de cantidad
        JLabel lblCantidad = new JLabel("Cantidad:");
        spnCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        panel.add(lblCantidad);
        panel.add(spnCantidad);

        // Botón para agregar al pedido
        btnAgregar = new JButton("Agregar al pedido");
        panel.add(btnAgregar);

        // Listado del pedido
        modeloPedido = new DefaultListModel<>();
        listaPedido = new JList<>(modeloPedido);
        JScrollPane scrollPane = new JScrollPane(listaPedido);
        panel.add(scrollPane);

        // Botones de confirmación y cancelación
        JButton btnConfirmar = new JButton("Confirmar pedido");
        JButton btnCancelar = new JButton("Cancelar pedido");
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnConfirmar);
        panelBotones.add(btnCancelar);
        panel.add(panelBotones);

        // Botón para eliminar producto
        btnEliminar = new JButton("Eliminar producto");
        panel.add(btnEliminar);

        // Cargar los sabores desde la base de datos al iniciar la app
        cargarSabores();
        
        btnConfirmar.addActionListener(e -> {
        if (modeloPedido.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No has agregado productos al pedido.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double precioTotal = 0.0;
        List<String> productos = new ArrayList<>(); // Lista para los productos

        Conexion conexion = new Conexion();
        try (Connection conn = conexion.getConnection()) {
            conn.setAutoCommit(false);

            // Insertar en la tabla pedidos
            String sqlPedido = "INSERT INTO pedidos (id_cliente, fecha_pedido, fecha_entrega, total, estado) VALUES (?, NOW(), ?, ?, ?)";
            try (PreparedStatement psPedido = conn.prepareStatement(sqlPedido, Statement.RETURN_GENERATED_KEYS)) {
                Integer idCliente = null; // Cambiar a un valor válido si usas autenticación
                String fechaEntrega = "2024-12-01"; // Fecha predeterminada o calculada
                String estado = "Pendiente";

                // Calcular el total del pedido y construir la lista de productos
                for (int i = 0; i < modeloPedido.size(); i++) {
                    String item = modeloPedido.getElementAt(i);
                    String[] partes = item.split(" ");
                    String sabor = partes[0];
                    String tamaño = partes[1].replace("(", "").replace(")", "");

                    // Obtener el tamaño del ComboBox
                    String tamañoSeleccionado = (String) comboTamaño.getSelectedItem();
                    if (tamañoSeleccionado == null) {
                        JOptionPane.showMessageDialog(this, "Por favor, selecciona un tamaño.", "Error", JOptionPane.WARNING_MESSAGE);
                        return;
                    }

                    // Obtener la cantidad directamente del JSpinner
                    int cantidad = (int) spnCantidad.getValue();

                    // Obtener el precio según el sabor y el tamaño seleccionados
                    double precioUnitario = obtenerPrecio(sabor, tamañoSeleccionado);
                    double totalItem = precioUnitario * cantidad;

                    productos.add(String.format("%s %s x%d: $%.2f", sabor, tamañoSeleccionado, cantidad, totalItem));
                    precioTotal += totalItem;
                }

                // Asignar valores al pedido
                psPedido.setObject(1, idCliente); // `id_cliente` puede ser NULL
                psPedido.setString(2, fechaEntrega);
                psPedido.setDouble(3, precioTotal);
                psPedido.setString(4, estado);
                psPedido.executeUpdate();

                // Obtener el ID generado para el pedido
                ResultSet rs = psPedido.getGeneratedKeys();
                if (rs.next()) {
                    int idPedido = rs.getInt(1);
                    JOptionPane.showMessageDialog(this, "Pedido confirmado con ID: " + idPedido);
                }

                conn.commit(); // Confirmar la transacción
            } catch (SQLException ex) {
                conn.rollback(); // Revertir en caso de error
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al guardar el pedido: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error de conexión: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Mostrar la factura en una nueva ventana
        new FacturaGUI(productos, precioTotal);

        // Limpiar la lista y restablecer la interfaz
        modeloPedido.clear();
        comboSabor.setSelectedIndex(-1);
        comboTamaño.setSelectedIndex(-1);
        spnCantidad.setValue(1);
    });

       
        // Acción para cancelar el pedido
        btnCancelar.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(this, "¿Estás seguro de cancelar el pedido?", "Cancelar Pedido", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                // Limpiar el listado del pedido
                modeloPedido.clear();
                lblPrecio.setText("Precio: $0.00");
                // Opcional: Resetear la selección en los combobox y spinner
                comboSabor.setSelectedIndex(-1);
                comboTamaño.setSelectedIndex(-1);
                spnCantidad.setValue(1);  // Restablecer cantidad a 1
            }
        });


        // Acción para agregar al pedido
        btnAgregar.addActionListener(e -> {
            String sabor = (String) comboSabor.getSelectedItem();
            String tamaño = (String) comboTamaño.getSelectedItem();
            int cantidad = (Integer) spnCantidad.getValue();
            double precio = obtenerPrecio(sabor, tamaño);  // Lógica para obtener el precio desde la base de datos
            lblPrecio.setText("Precio: $" + precio);

            // Agregar el helado al listado del pedido
            modeloPedido.addElement(sabor + " (" + tamaño + ") x" + cantidad);
        });

        // Acción para eliminar el producto seleccionado
        btnEliminar.addActionListener(e -> {
            int indexSeleccionado = listaPedido.getSelectedIndex();

            if (indexSeleccionado != -1) {
                modeloPedido.remove(indexSeleccionado);
            } else {
                JOptionPane.showMessageDialog(this, "Por favor, selecciona un producto para eliminar.", "Error", JOptionPane.WARNING_MESSAGE);
            }
        });

        // Actualizar tamaños cuando se seleccione un sabor
        comboSabor.addActionListener(e -> actualizarTamanos());

        setVisible(true);
    }

    private void cargarSabores() {
        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();
            
            if (conn != null) {
                // Consulta SQL para obtener los sabores
                String sql = "SELECT DISTINCT nombre_sabor FROM helados";
                PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                
                // Limpiar el JComboBox antes de cargar nuevos datos
                comboSabor.removeAllItems();
                
                while (rs.next()) {
                    comboSabor.addItem(rs.getString("nombre_sabor"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar los sabores: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarTamanos() {
        String saborSeleccionado = (String) comboSabor.getSelectedItem();
        if (saborSeleccionado != null) {
            try {
                Conexion conexion = new Conexion();
                Connection conn = conexion.getConnection();

                if (conn != null) {
                    // Consulta SQL para obtener los tamaños disponibles para el sabor seleccionado
                    String sql = "SELECT DISTINCT nombre_tamaño FROM helados WHERE nombre_sabor = ?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setString(1, saborSeleccionado);
                    ResultSet rs = ps.executeQuery();
                    
                    // Limpiar el JComboBox de tamaños antes de agregar nuevos datos
                    comboTamaño.removeAllItems();
                    
                    while (rs.next()) {
                        comboTamaño.addItem(rs.getString("nombre_tamaño"));
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al cargar los tamaños: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private double obtenerPrecio(String sabor, String tamaño) {
        double precio = 0.0;

        try {
            Conexion conexion = new Conexion();
            Connection conn = conexion.getConnection();

            if (conn != null) {
                // Consulta SQL para obtener el precio de acuerdo al sabor y tamaño
                String sql = "SELECT precio FROM helados WHERE nombre_sabor = ? AND nombre_tamaño = ?";

                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, sabor);
                    ps.setString(2, tamaño);

                    ResultSet rs = ps.executeQuery();

                    if (rs.next()) {
                        precio = rs.getDouble("precio");
                    } else {
                        JOptionPane.showMessageDialog(this, "No se encontró el precio para este sabor y tamaño.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al obtener el precio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return precio;
    }

    public static void main(String[] args) {
        new HeladeriaApp();
    }
}